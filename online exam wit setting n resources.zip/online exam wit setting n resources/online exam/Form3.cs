﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Reflection;
using System.Resources;

namespace online_exam
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true&&checkBox1.Checked==false&&checkBox3.Checked==false)
            {
                Form5 d = new Form5();
                if (textBox1.Text == "2")
                {
                    if (radioButton1.Checked == true)
                    {
                        d.label14.BackColor = Color.Green;
                    }
                    else { d.label14.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        d.label13.BackColor = Color.Green;
                    }
                    else { d.label13.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        d.label12.BackColor = Color.Green;
                    }
                    else { d.label12.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        d.label11.BackColor = Color.Green;
                    }
                    else { d.label11.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        d.label10.BackColor = Color.Green;
                    }
                    else { d.label10.BackColor = Color.Red; }
                    d.Show();


                }
                if (textBox1.Text == "3")
                {
                    if (radioButton2.Checked == true)
                    {
                        d.label14.BackColor = Color.Green;
                    }
                    else { d.label14.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        d.label13.BackColor = Color.Green;
                    }
                    else { d.label13.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        d.label12.BackColor = Color.Green;
                    }
                    else { d.label12.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        d.label11.BackColor = Color.Green;
                    }
                    else { d.label11.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        d.label10.BackColor = Color.Green;
                    }
                    else { d.label10.BackColor = Color.Red; }
                    d.Show();


                }



                if (textBox1.Text == "4")
                {
                    if (radioButton3.Checked == true)
                    {
                        d.label14.BackColor = Color.Green;
                    }
                    else { d.label14.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        d.label13.BackColor = Color.Green;
                    }
                    else { d.label13.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        d.label12.BackColor = Color.Green;
                    }
                    else { d.label12.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        d.label11.BackColor = Color.Green;
                    }
                    else { d.label11.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        d.label10.BackColor = Color.Green;
                    }
                    else { d.label10.BackColor = Color.Red; }
                    d.Show();


                }
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true&&checkBox3.Checked==false)
            {
                Form5 d = new Form5();

                if (textBox1.Text == "2")
                {
                    
                if (radioButton1.Checked == true)
                {
                    d.label14.BackColor = Color.Green;
                }
                else { d.label14.BackColor = Color.Red; }

                if (radioButton5.Checked == true)
                {
                    d.label13.BackColor = Color.Green;
                }
                else { d.label13.BackColor = Color.Red; }

                if (radioButton9.Checked == true)
                {
                    d.label12.BackColor = Color.Green;
                }
                else { d.label12.BackColor = Color.Red; }

                if (radioButton13.Checked == true)
                {
                    d.label11.BackColor = Color.Green;
                }
                else { d.label11.BackColor = Color.Red; }

                if (radioButton17.Checked == true)
                {
                    d.label10.BackColor = Color.Green;
                }
                else { d.label10.BackColor = Color.Red; }
                d.Show();


                d.label5.BackColor = label6.BackColor;
                d.label6.BackColor = label7.BackColor;
                d.label7.BackColor = label8.BackColor;
                d.label8.BackColor = label9.BackColor;
                d.label9.BackColor = label10.BackColor;



            }
                if (textBox1.Text == "3")
                {
                    if (radioButton2.Checked == true)
                    {
                        d.label14.BackColor = Color.Green;
                    }
                    else { d.label14.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        d.label13.BackColor = Color.Green;
                    }
                    else { d.label13.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        d.label12.BackColor = Color.Green;
                    }
                    else { d.label12.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        d.label11.BackColor = Color.Green;
                    }
                    else { d.label11.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        d.label10.BackColor = Color.Green;
                    }
                    else { d.label10.BackColor = Color.Red; }
                    d.Show();

                    d.label5.BackColor = label6.BackColor;
                    d.label6.BackColor = label7.BackColor;
                    d.label7.BackColor = label8.BackColor;
                    d.label8.BackColor = label9.BackColor;
                    d.label9.BackColor = label10.BackColor;

                }
                if (textBox1.Text == "4")
                {
                    if (radioButton3.Checked == true)
                    {
                        d.label14.BackColor = Color.Green;
                    }
                    else { d.label14.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        d.label13.BackColor = Color.Green;
                    }
                    else { d.label13.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        d.label12.BackColor = Color.Green;
                    }
                    else { d.label12.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        d.label11.BackColor = Color.Green;
                    }
                    else { d.label11.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        d.label10.BackColor = Color.Green;
                    }
                    else { d.label10.BackColor = Color.Red; }
                    d.Show();

                    d.label5.BackColor = label6.BackColor;
                    d.label6.BackColor = label7.BackColor;
                    d.label7.BackColor = label8.BackColor;
                    d.label8.BackColor = label9.BackColor;
                    d.label9.BackColor = label10.BackColor;
                }
             
            }
            if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form4 c = new Form4();
                c.checkBox2.Checked = true;
                c.checkBox3.Checked = true;
                ResourceManager res3 = new ResourceManager("online_exam.Resource3", Assembly.GetExecutingAssembly());
                ResourceManager res4 = new ResourceManager("online_exam.Resource4", Assembly.GetExecutingAssembly());
                Properties.Settings ps = new Properties.Settings();

                if (textBox1.Text == "2")
                {
                    c.textBox1.Text = textBox1.Text;

                    c.label1.Text = res3.GetString("a1");
                    c.label2.Text = res3.GetString("a2");
                    c.label3.Text = res3.GetString("a3");
                    c.label4.Text = res3.GetString("a4");
                    c.label5.Text = res3.GetString("a5");

                    c.radioButton1.Text = res4.GetString("a1");
                    c.radioButton2.Text = res4.GetString("a2");
                    c.radioButton3.Text = res4.GetString("a3");
                    c.radioButton4.Text = res4.GetString("a4");

                    c.radioButton5.Text = res4.GetString("a5");
                    c.radioButton6.Text = res4.GetString("a6");
                    c.radioButton7.Text = res4.GetString("a7");
                    c.radioButton8.Text = res4.GetString("a8");

                    c.radioButton9.Text = res4.GetString("a9");
                    c.radioButton10.Text = res4.GetString("a10");
                    c.radioButton11.Text = res4.GetString("a11");
                    c.radioButton12.Text = res4.GetString("a12");

                    c.radioButton13.Text = res4.GetString("a13");
                    c.radioButton14.Text = res4.GetString("a14");
                    c.radioButton15.Text = res4.GetString("a15");
                    c.radioButton16.Text = res4.GetString("a16");

                    c.radioButton17.Text = res4.GetString("a17");
                    c.radioButton18.Text = res4.GetString("a18");
                    c.radioButton19.Text = res4.GetString("a19");
                    c.radioButton20.Text = res4.GetString("a20");

                    c.Show();
                    ps.name = "3";
                    ps.Save();
                    if (radioButton1.Checked == true)
                    {
                        c.label15.BackColor = Color.Green;
                    }
                    else { c.label15.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        c.label14.BackColor = Color.Green;
                    }
                    else { c.label14.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        c.label13.BackColor = Color.Green;
                    }
                    else { c.label13.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        c.label12.BackColor = Color.Green;
                    }
                    else { c.label12.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        c.label11.BackColor = Color.Green;
                    }
                    else { c.label11.BackColor = Color.Red; }
                    c.Show();


                }

                if (textBox1.Text == "3")
                {
                    c.textBox1.Text = textBox1.Text;

                    c.label1.Text = res3.GetString("a6");
                    c.label2.Text = res3.GetString("a7");
                    c.label3.Text = res3.GetString("a8");
                    c.label4.Text = res3.GetString("a9");
                    c.label5.Text = res3.GetString("a10");

                    c.radioButton1.Text = res4.GetString("a1");
                    c.radioButton2.Text = res4.GetString("a2");
                    c.radioButton3.Text = res4.GetString("a3");
                    c.radioButton4.Text = res4.GetString("a4");

                    c.radioButton5.Text = res4.GetString("a5");
                    c.radioButton6.Text = res4.GetString("a6");
                    c.radioButton7.Text = res4.GetString("a7");
                    c.radioButton8.Text = res4.GetString("a8");

                    c.radioButton9.Text = res4.GetString("a9");
                    c.radioButton10.Text = res4.GetString("a10");
                    c.radioButton11.Text = res4.GetString("a11");
                    c.radioButton12.Text = res4.GetString("a12");

                    c.radioButton13.Text = res4.GetString("a13");
                    c.radioButton14.Text = res4.GetString("a14");
                    c.radioButton15.Text = res4.GetString("a15");
                    c.radioButton16.Text = res4.GetString("a16");

                    c.radioButton17.Text = res4.GetString("a17");
                    c.radioButton18.Text = res4.GetString("a18");
                    c.radioButton19.Text = res4.GetString("a19");
                    c.radioButton20.Text = res4.GetString("a20");

                    c.Show();
                    ps.name = "4";
                    ps.Save();
                    if (radioButton2.Checked == true)
                    {
                        c.label15.BackColor = Color.Green;
                    }
                    else { c.label15.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        c.label14.BackColor = Color.Green;
                    }
                    else { c.label14.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        c.label13.BackColor = Color.Green;
                    }
                    else { c.label13.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        c.label12.BackColor = Color.Green;
                    }
                    else { c.label12.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        c.label11.BackColor = Color.Green;
                    }
                    else { c.label11.BackColor = Color.Red; }
                    c.Show();


                }
                if (textBox1.Text == "4")
                {
                    c.textBox1.Text = textBox1.Text;

                    c.label1.Text = res3.GetString("a11");
                    c.label2.Text = res3.GetString("a12");
                    c.label3.Text = res3.GetString("a13");
                    c.label4.Text = res3.GetString("a14");
                    c.label5.Text = res3.GetString("a15");

                    c.radioButton1.Text = res4.GetString("a1");
                    c.radioButton2.Text = res4.GetString("a2");
                    c.radioButton3.Text = res4.GetString("a3");
                    c.radioButton4.Text = res4.GetString("a4");

                    c.radioButton5.Text = res4.GetString("a5");
                    c.radioButton6.Text = res4.GetString("a6");
                    c.radioButton7.Text = res4.GetString("a7");
                    c.radioButton8.Text = res4.GetString("a8");

                    c.radioButton9.Text = res4.GetString("a9");
                    c.radioButton10.Text = res4.GetString("a10");
                    c.radioButton11.Text = res4.GetString("a11");
                    c.radioButton12.Text = res4.GetString("a12");

                    c.radioButton13.Text = res4.GetString("a13");
                    c.radioButton14.Text = res4.GetString("a14");
                    c.radioButton15.Text = res4.GetString("a15");
                    c.radioButton16.Text = res4.GetString("a16");

                    c.radioButton17.Text = res4.GetString("a17");
                    c.radioButton18.Text = res4.GetString("a18");
                    c.radioButton19.Text = res4.GetString("a19");
                    c.radioButton20.Text = res4.GetString("a20");

                    c.Show();
                    ps.name = "2";
                    ps.Save();
                    if (radioButton3.Checked == true)
                    {
                        c.label15.BackColor = Color.Green;
                    }
                    else { c.label15.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        c.label14.BackColor = Color.Green;
                    }
                    else { c.label14.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        c.label13.BackColor = Color.Green;
                    }
                    else { c.label13.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        c.label12.BackColor = Color.Green;
                    }
                    else { c.label12.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        c.label11.BackColor = Color.Green;
                    }
                    else { c.label11.BackColor = Color.Red; }
                    c.Show();


                }
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form4 c = new Form4();
                c.checkBox2.Checked = true;
                c.checkBox1.Checked = true;
                c.checkBox3.Checked = true;

                ResourceManager res3 = new ResourceManager("online_exam.Resource3", Assembly.GetExecutingAssembly());
                ResourceManager res4 = new ResourceManager("online_exam.Resource4", Assembly.GetExecutingAssembly());
                Properties.Settings ps = new Properties.Settings();

                if (textBox1.Text == "2")
                {
                    c.textBox1.Text = textBox1.Text;

                    c.label1.Text = res3.GetString("a1");
                    c.label2.Text = res3.GetString("a2");
                    c.label3.Text = res3.GetString("a3");
                    c.label4.Text = res3.GetString("a4");
                    c.label5.Text = res3.GetString("a5");

                    c.radioButton1.Text = res4.GetString("a1");
                    c.radioButton2.Text = res4.GetString("a2");
                    c.radioButton3.Text = res4.GetString("a3");
                    c.radioButton4.Text = res4.GetString("a4");

                    c.radioButton5.Text = res4.GetString("a5");
                    c.radioButton6.Text = res4.GetString("a6");
                    c.radioButton7.Text = res4.GetString("a7");
                    c.radioButton8.Text = res4.GetString("a8");

                    c.radioButton9.Text = res4.GetString("a9");
                    c.radioButton10.Text = res4.GetString("a10");
                    c.radioButton11.Text = res4.GetString("a11");
                    c.radioButton12.Text = res4.GetString("a12");

                    c.radioButton13.Text = res4.GetString("a13");
                    c.radioButton14.Text = res4.GetString("a14");
                    c.radioButton15.Text = res4.GetString("a15");
                    c.radioButton16.Text = res4.GetString("a16");

                    c.radioButton17.Text = res4.GetString("a17");
                    c.radioButton18.Text = res4.GetString("a18");
                    c.radioButton19.Text = res4.GetString("a19");
                    c.radioButton20.Text = res4.GetString("a20");

                    c.Show();
                    ps.name = "3";
                    ps.Save();
                    if (radioButton1.Checked == true)
                    {
                        c.label15.BackColor = Color.Green;
                    }
                    else { c.label15.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        c.label14.BackColor = Color.Green;
                    }
                    else { c.label14.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        c.label13.BackColor = Color.Green;
                    }
                    else { c.label13.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        c.label12.BackColor = Color.Green;
                    }
                    else { c.label12.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        c.label11.BackColor = Color.Green;
                    }
                    else { c.label11.BackColor = Color.Red; }
                    c.Show();

                    c.label6.BackColor = label6.BackColor;
                    c.label7.BackColor = label7.BackColor;
                    c.label8.BackColor = label8.BackColor;
                    c.label9.BackColor = label9.BackColor;
                    c.label10.BackColor = label10.BackColor;
                }

                if (textBox1.Text == "3")
                {
                    c.textBox1.Text = textBox1.Text;

                    c.label1.Text = res3.GetString("a6");
                    c.label2.Text = res3.GetString("a7");
                    c.label3.Text = res3.GetString("a8");
                    c.label4.Text = res3.GetString("a9");
                    c.label5.Text = res3.GetString("a10");

                    c.radioButton1.Text = res4.GetString("a1");
                    c.radioButton2.Text = res4.GetString("a2");
                    c.radioButton3.Text = res4.GetString("a3");
                    c.radioButton4.Text = res4.GetString("a4");

                    c.radioButton5.Text = res4.GetString("a5");
                    c.radioButton6.Text = res4.GetString("a6");
                    c.radioButton7.Text = res4.GetString("a7");
                    c.radioButton8.Text = res4.GetString("a8");

                    c.radioButton9.Text = res4.GetString("a9");
                    c.radioButton10.Text = res4.GetString("a10");
                    c.radioButton11.Text = res4.GetString("a11");
                    c.radioButton12.Text = res4.GetString("a12");

                    c.radioButton13.Text = res4.GetString("a13");
                    c.radioButton14.Text = res4.GetString("a14");
                    c.radioButton15.Text = res4.GetString("a15");
                    c.radioButton16.Text = res4.GetString("a16");

                    c.radioButton17.Text = res4.GetString("a17");
                    c.radioButton18.Text = res4.GetString("a18");
                    c.radioButton19.Text = res4.GetString("a19");
                    c.radioButton20.Text = res4.GetString("a20");

                    c.Show();
                    ps.name = "4";
                    ps.Save();
                    if (radioButton2.Checked == true)
                    {
                        c.label15.BackColor = Color.Green;
                    }
                    else { c.label15.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        c.label14.BackColor = Color.Green;
                    }
                    else { c.label14.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        c.label13.BackColor = Color.Green;
                    }
                    else { c.label13.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        c.label12.BackColor = Color.Green;
                    }
                    else { c.label12.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        c.label11.BackColor = Color.Green;
                    }
                    else { c.label11.BackColor = Color.Red; }
                    c.Show();

                    c.label6.BackColor = label6.BackColor;
                    c.label7.BackColor = label7.BackColor;
                    c.label8.BackColor = label8.BackColor;
                    c.label9.BackColor = label9.BackColor;
                    c.label10.BackColor = label10.BackColor;
                }
                if (textBox1.Text == "4")
                {
                    c.textBox1.Text = textBox1.Text;

                    c.label1.Text = res3.GetString("a11");
                    c.label2.Text = res3.GetString("a12");
                    c.label3.Text = res3.GetString("a13");
                    c.label4.Text = res3.GetString("a14");
                    c.label5.Text = res3.GetString("a15");

                    c.radioButton1.Text = res4.GetString("a1");
                    c.radioButton2.Text = res4.GetString("a2");
                    c.radioButton3.Text = res4.GetString("a3");
                    c.radioButton4.Text = res4.GetString("a4");

                    c.radioButton5.Text = res4.GetString("a5");
                    c.radioButton6.Text = res4.GetString("a6");
                    c.radioButton7.Text = res4.GetString("a7");
                    c.radioButton8.Text = res4.GetString("a8");

                    c.radioButton9.Text = res4.GetString("a9");
                    c.radioButton10.Text = res4.GetString("a10");
                    c.radioButton11.Text = res4.GetString("a11");
                    c.radioButton12.Text = res4.GetString("a12");

                    c.radioButton13.Text = res4.GetString("a13");
                    c.radioButton14.Text = res4.GetString("a14");
                    c.radioButton15.Text = res4.GetString("a15");
                    c.radioButton16.Text = res4.GetString("a16");

                    c.radioButton17.Text = res4.GetString("a17");
                    c.radioButton18.Text = res4.GetString("a18");
                    c.radioButton19.Text = res4.GetString("a19");
                    c.radioButton20.Text = res4.GetString("a20");

                    c.Show();
                    ps.name = "2";
                    ps.Save();
                    if (radioButton3.Checked == true)
                    {
                        c.label15.BackColor = Color.Green;
                    }
                    else { c.label15.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        c.label14.BackColor = Color.Green;
                    }
                    else { c.label14.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        c.label13.BackColor = Color.Green;
                    }
                    else { c.label13.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        c.label12.BackColor = Color.Green;
                    }
                    else { c.label12.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        c.label11.BackColor = Color.Green;
                    }
                    else { c.label11.BackColor = Color.Red; }
                    c.Show();

                    c.label6.BackColor = label6.BackColor;
                    c.label7.BackColor = label7.BackColor;
                    c.label8.BackColor = label8.BackColor;
                    c.label9.BackColor = label9.BackColor;
                    c.label10.BackColor = label10.BackColor;
                }
            }
        }
    }
}
