﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Resources;
using System.Reflection;

namespace online_exam
{
    public partial class Form1 : Form 
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void button1_Click1(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                if (radioButton1.Checked == true || radioButton2.Checked == true)
                {

                    if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
                    {

                        Form2 a = new Form2();
                        a.checkBox1.Checked = true;
                        ResourceManager res = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
                        ResourceManager abc = new ResourceManager("online_exam.abc", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();
                        if (textBox1.Text == "2")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a1");
                            a.label2.Text = res.GetString("a2");
                            a.label3.Text = res.GetString("a3");
                            a.label4.Text = res.GetString("a4");
                            a.label5.Text = res.GetString("a5");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "3";
                            ps.Save();


                        }
                        if (textBox1.Text == "3")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a6");
                            a.label2.Text = res.GetString("a7");
                            a.label3.Text = res.GetString("a8");
                            a.label4.Text = res.GetString("a9");
                            a.label5.Text = res.GetString("a10");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "4";
                            ps.Save();

                        }
                        if (textBox1.Text == "4")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a11");
                            a.label2.Text = res.GetString("a12");
                            a.label3.Text = res.GetString("a13");
                            a.label4.Text = res.GetString("a14");
                            a.label5.Text = res.GetString("a15");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();
                            ps.name = "2";
                            ps.Save();

                        }
                    }
                    if (checkBox2.Checked == true && checkBox1.Checked == false && checkBox3.Checked == false)
                    {
                        Form3 b = new Form3();
                        b.checkBox2.Checked = true;
                        ResourceManager res1 = new ResourceManager("online_exam.Resource1", Assembly.GetExecutingAssembly());
                        ResourceManager res2 = new ResourceManager("online_exam.Resource2", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();

                        if (textBox1.Text == "2")
                        {
                            b.textBox1.Text = textBox1.Text;

                            b.label1.Text = res1.GetString("a1");
                            b.label2.Text = res1.GetString("a2");
                            b.label3.Text = res1.GetString("a3");
                            b.label4.Text = res1.GetString("a4");
                            b.label5.Text = res1.GetString("a5");

                            b.radioButton1.Text = res2.GetString("a1");
                            b.radioButton2.Text = res2.GetString("a2");
                            b.radioButton3.Text = res2.GetString("a3");
                            b.radioButton4.Text = res2.GetString("a4");

                            b.radioButton5.Text = res2.GetString("a5");
                            b.radioButton6.Text = res2.GetString("a6");
                            b.radioButton7.Text = res2.GetString("a7");
                            b.radioButton8.Text = res2.GetString("a8");

                            b.radioButton9.Text = res2.GetString("a9");
                            b.radioButton10.Text = res2.GetString("a10");
                            b.radioButton11.Text = res2.GetString("a11");
                            b.radioButton12.Text = res2.GetString("a12");

                            b.radioButton13.Text = res2.GetString("a13");
                            b.radioButton14.Text = res2.GetString("a14");
                            b.radioButton15.Text = res2.GetString("a15");
                            b.radioButton16.Text = res2.GetString("a16");

                            b.radioButton17.Text = res2.GetString("a17");
                            b.radioButton18.Text = res2.GetString("a18");
                            b.radioButton19.Text = res2.GetString("a19");
                            b.radioButton20.Text = res2.GetString("a20");

                            b.Show();
                            ps.name = "3";
                            ps.Save();


                        }
                        if (textBox1.Text == "3")
                        {
                            b.textBox1.Text = textBox1.Text;

                            b.label1.Text = res1.GetString("a6");
                            b.label2.Text = res1.GetString("a7");
                            b.label3.Text = res1.GetString("a8");
                            b.label4.Text = res1.GetString("a9");
                            b.label5.Text = res1.GetString("a10");

                            b.radioButton1.Text = res2.GetString("a1");
                            b.radioButton2.Text = res2.GetString("a2");
                            b.radioButton3.Text = res2.GetString("a3");
                            b.radioButton4.Text = res2.GetString("a4");

                            b.radioButton5.Text = res2.GetString("a5");
                            b.radioButton6.Text = res2.GetString("a6");
                            b.radioButton7.Text = res2.GetString("a7");
                            b.radioButton8.Text = res2.GetString("a8");

                            b.radioButton9.Text = res2.GetString("a9");
                            b.radioButton10.Text = res2.GetString("a10");
                            b.radioButton11.Text = res2.GetString("a11");
                            b.radioButton12.Text = res2.GetString("a12");

                            b.radioButton13.Text = res2.GetString("a13");
                            b.radioButton14.Text = res2.GetString("a14");
                            b.radioButton15.Text = res2.GetString("a15");
                            b.radioButton16.Text = res2.GetString("a16");

                            b.radioButton17.Text = res2.GetString("a17");
                            b.radioButton18.Text = res2.GetString("a18");
                            b.radioButton19.Text = res2.GetString("a19");
                            b.radioButton20.Text = res2.GetString("a20");

                            b.Show();
                            ps.name = "4";
                            ps.Save();


                        }
                        if (textBox1.Text == "4")
                        {
                            b.textBox1.Text = textBox1.Text;

                            b.label1.Text = res1.GetString("a11");
                            b.label2.Text = res1.GetString("a12");
                            b.label3.Text = res1.GetString("a13");
                            b.label4.Text = res1.GetString("a14");
                            b.label5.Text = res1.GetString("a15");

                            b.radioButton1.Text = res2.GetString("a1");
                            b.radioButton2.Text = res2.GetString("a2");
                            b.radioButton3.Text = res2.GetString("a3");
                            b.radioButton4.Text = res2.GetString("a4");

                            b.radioButton5.Text = res2.GetString("a5");
                            b.radioButton6.Text = res2.GetString("a6");
                            b.radioButton7.Text = res2.GetString("a7");
                            b.radioButton8.Text = res2.GetString("a8");

                            b.radioButton9.Text = res2.GetString("a9");
                            b.radioButton10.Text = res2.GetString("a10");
                            b.radioButton11.Text = res2.GetString("a11");
                            b.radioButton12.Text = res2.GetString("a12");

                            b.radioButton13.Text = res2.GetString("a13");
                            b.radioButton14.Text = res2.GetString("a14");
                            b.radioButton15.Text = res2.GetString("a15");
                            b.radioButton16.Text = res2.GetString("a16");

                            b.radioButton17.Text = res2.GetString("a17");
                            b.radioButton18.Text = res2.GetString("a18");
                            b.radioButton19.Text = res2.GetString("a19");
                            b.radioButton20.Text = res2.GetString("a20");

                            b.Show();
                            ps.name = "2";
                            ps.Save();


                        }

                    }
                    if (checkBox3.Checked == true && checkBox1.Checked == false && checkBox2.Checked == false)
                    {
                        Form4 c = new Form4();
                        c.checkBox3.Checked = true;
                        ResourceManager res3 = new ResourceManager("online_exam.Resource3", Assembly.GetExecutingAssembly());
                        ResourceManager res4 = new ResourceManager("online_exam.Resource4", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();

                        if (textBox1.Text == "2")
                        {
                            c.textBox1.Text = textBox1.Text;

                            c.label1.Text = res3.GetString("a1");
                            c.label2.Text = res3.GetString("a2");
                            c.label3.Text = res3.GetString("a3");
                            c.label4.Text = res3.GetString("a4");
                            c.label5.Text = res3.GetString("a5");

                            c.radioButton1.Text = res4.GetString("a1");
                            c.radioButton2.Text = res4.GetString("a2");
                            c.radioButton3.Text = res4.GetString("a3");
                            c.radioButton4.Text = res4.GetString("a4");

                            c.radioButton5.Text = res4.GetString("a5");
                            c.radioButton6.Text = res4.GetString("a6");
                            c.radioButton7.Text = res4.GetString("a7");
                            c.radioButton8.Text = res4.GetString("a8");

                            c.radioButton9.Text = res4.GetString("a9");
                            c.radioButton10.Text = res4.GetString("a10");
                            c.radioButton11.Text = res4.GetString("a11");
                            c.radioButton12.Text = res4.GetString("a12");

                            c.radioButton13.Text = res4.GetString("a13");
                            c.radioButton14.Text = res4.GetString("a14");
                            c.radioButton15.Text = res4.GetString("a15");
                            c.radioButton16.Text = res4.GetString("a16");

                            c.radioButton17.Text = res4.GetString("a17");
                            c.radioButton18.Text = res4.GetString("a18");
                            c.radioButton19.Text = res4.GetString("a19");
                            c.radioButton20.Text = res4.GetString("a20");

                            c.Show();
                            ps.name = "3";
                            ps.Save();


                        }

                        if (textBox1.Text == "3")
                        {
                            c.textBox1.Text = textBox1.Text;

                            c.label1.Text = res3.GetString("a6");
                            c.label2.Text = res3.GetString("a7");
                            c.label3.Text = res3.GetString("a8");
                            c.label4.Text = res3.GetString("a9");
                            c.label5.Text = res3.GetString("a10");

                            c.radioButton1.Text = res4.GetString("a1");
                            c.radioButton2.Text = res4.GetString("a2");
                            c.radioButton3.Text = res4.GetString("a3");
                            c.radioButton4.Text = res4.GetString("a4");

                            c.radioButton5.Text = res4.GetString("a5");
                            c.radioButton6.Text = res4.GetString("a6");
                            c.radioButton7.Text = res4.GetString("a7");
                            c.radioButton8.Text = res4.GetString("a8");

                            c.radioButton9.Text = res4.GetString("a9");
                            c.radioButton10.Text = res4.GetString("a10");
                            c.radioButton11.Text = res4.GetString("a11");
                            c.radioButton12.Text = res4.GetString("a12");

                            c.radioButton13.Text = res4.GetString("a13");
                            c.radioButton14.Text = res4.GetString("a14");
                            c.radioButton15.Text = res4.GetString("a15");
                            c.radioButton16.Text = res4.GetString("a16");

                            c.radioButton17.Text = res4.GetString("a17");
                            c.radioButton18.Text = res4.GetString("a18");
                            c.radioButton19.Text = res4.GetString("a19");
                            c.radioButton20.Text = res4.GetString("a20");

                            c.Show();
                            ps.name = "4";
                            ps.Save();


                        }

                        if (textBox1.Text == "4")
                        {
                            c.textBox1.Text = textBox1.Text;

                            c.label1.Text = res3.GetString("a11");
                            c.label2.Text = res3.GetString("a12");
                            c.label3.Text = res3.GetString("a13");
                            c.label4.Text = res3.GetString("a14");
                            c.label5.Text = res3.GetString("a15");

                            c.radioButton1.Text = res4.GetString("a1");
                            c.radioButton2.Text = res4.GetString("a2");
                            c.radioButton3.Text = res4.GetString("a3");
                            c.radioButton4.Text = res4.GetString("a4");

                            c.radioButton5.Text = res4.GetString("a5");
                            c.radioButton6.Text = res4.GetString("a6");
                            c.radioButton7.Text = res4.GetString("a7");
                            c.radioButton8.Text = res4.GetString("a8");

                            c.radioButton9.Text = res4.GetString("a9");
                            c.radioButton10.Text = res4.GetString("a10");
                            c.radioButton11.Text = res4.GetString("a11");
                            c.radioButton12.Text = res4.GetString("a12");

                            c.radioButton13.Text = res4.GetString("a13");
                            c.radioButton14.Text = res4.GetString("a14");
                            c.radioButton15.Text = res4.GetString("a15");
                            c.radioButton16.Text = res4.GetString("a16");

                            c.radioButton17.Text = res4.GetString("a17");
                            c.radioButton18.Text = res4.GetString("a18");
                            c.radioButton19.Text = res4.GetString("a19");
                            c.radioButton20.Text = res4.GetString("a20");

                            c.Show();
                            ps.name = "2";
                            ps.Save();


                        }
                    }
                    if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
                    {
                        Form2 a = new Form2();
                        Form3 b = new Form3();
                        a.checkBox1.Checked = true;
                        a.checkBox2.Checked = true;


                        ResourceManager res = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
                        ResourceManager abc = new ResourceManager("online_exam.abc", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();
                        if (textBox1.Text == "2")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a1");
                            a.label2.Text = res.GetString("a2");
                            a.label3.Text = res.GetString("a3");
                            a.label4.Text = res.GetString("a4");
                            a.label5.Text = res.GetString("a5");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "3";
                            ps.Save();


                        }
                        if (textBox1.Text == "3")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a6");
                            a.label2.Text = res.GetString("a7");
                            a.label3.Text = res.GetString("a8");
                            a.label4.Text = res.GetString("a9");
                            a.label5.Text = res.GetString("a10");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "4";
                            ps.Save();

                        }
                        if (textBox1.Text == "4")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a11");
                            a.label2.Text = res.GetString("a12");
                            a.label3.Text = res.GetString("a13");
                            a.label4.Text = res.GetString("a14");
                            a.label5.Text = res.GetString("a15");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();
                            ps.name = "2";
                            ps.Save();

                        }
                    }
                    if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
                    {
                        Form2 a = new Form2();
                        Form4 c = new Form4();
                        a.checkBox1.Checked = true;
                        a.checkBox3.Checked = true;

                        ResourceManager res = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
                        ResourceManager abc = new ResourceManager("online_exam.abc", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();

                        if (textBox1.Text == "2")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a1");
                            a.label2.Text = res.GetString("a2");
                            a.label3.Text = res.GetString("a3");
                            a.label4.Text = res.GetString("a4");
                            a.label5.Text = res.GetString("a5");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "3";
                            ps.Save();

                        }
                        if (textBox1.Text == "3")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a6");
                            a.label2.Text = res.GetString("a7");
                            a.label3.Text = res.GetString("a8");
                            a.label4.Text = res.GetString("a9");
                            a.label5.Text = res.GetString("a10");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "4";
                            ps.Save();


                        }
                        if (textBox1.Text == "4")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a11");
                            a.label2.Text = res.GetString("a12");
                            a.label3.Text = res.GetString("a13");
                            a.label4.Text = res.GetString("a14");
                            a.label5.Text = res.GetString("a15");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();
                            ps.name = "2";
                            ps.Save();

                        }


                    }
                    if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
                    {
                        Form3 b = new Form3();
                        b.checkBox2.Checked = true;
                        b.checkBox3.Checked = true;

                        ResourceManager res1 = new ResourceManager("online_exam.Resource1", Assembly.GetExecutingAssembly());
                        ResourceManager res2 = new ResourceManager("online_exam.Resource2", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();

                        if (textBox1.Text == "2")
                        {
                            b.textBox1.Text = textBox1.Text;

                            b.label1.Text = res1.GetString("a1");
                            b.label2.Text = res1.GetString("a2");
                            b.label3.Text = res1.GetString("a3");
                            b.label4.Text = res1.GetString("a4");
                            b.label5.Text = res1.GetString("a5");

                            b.radioButton1.Text = res2.GetString("a1");
                            b.radioButton2.Text = res2.GetString("a2");
                            b.radioButton3.Text = res2.GetString("a3");
                            b.radioButton4.Text = res2.GetString("a4");

                            b.radioButton5.Text = res2.GetString("a5");
                            b.radioButton6.Text = res2.GetString("a6");
                            b.radioButton7.Text = res2.GetString("a7");
                            b.radioButton8.Text = res2.GetString("a8");

                            b.radioButton9.Text = res2.GetString("a9");
                            b.radioButton10.Text = res2.GetString("a10");
                            b.radioButton11.Text = res2.GetString("a11");
                            b.radioButton12.Text = res2.GetString("a12");

                            b.radioButton13.Text = res2.GetString("a13");
                            b.radioButton14.Text = res2.GetString("a14");
                            b.radioButton15.Text = res2.GetString("a15");
                            b.radioButton16.Text = res2.GetString("a16");

                            b.radioButton17.Text = res2.GetString("a17");
                            b.radioButton18.Text = res2.GetString("a18");
                            b.radioButton19.Text = res2.GetString("a19");
                            b.radioButton20.Text = res2.GetString("a20");

                            b.Show();
                            ps.name = "3";
                            ps.Save();


                        }
                        if (textBox1.Text == "3")
                        {
                            b.textBox1.Text = textBox1.Text;

                            b.label1.Text = res1.GetString("a6");
                            b.label2.Text = res1.GetString("a7");
                            b.label3.Text = res1.GetString("a8");
                            b.label4.Text = res1.GetString("a9");
                            b.label5.Text = res1.GetString("a10");

                            b.radioButton1.Text = res2.GetString("a1");
                            b.radioButton2.Text = res2.GetString("a2");
                            b.radioButton3.Text = res2.GetString("a3");
                            b.radioButton4.Text = res2.GetString("a4");

                            b.radioButton5.Text = res2.GetString("a5");
                            b.radioButton6.Text = res2.GetString("a6");
                            b.radioButton7.Text = res2.GetString("a7");
                            b.radioButton8.Text = res2.GetString("a8");

                            b.radioButton9.Text = res2.GetString("a9");
                            b.radioButton10.Text = res2.GetString("a10");
                            b.radioButton11.Text = res2.GetString("a11");
                            b.radioButton12.Text = res2.GetString("a12");

                            b.radioButton13.Text = res2.GetString("a13");
                            b.radioButton14.Text = res2.GetString("a14");
                            b.radioButton15.Text = res2.GetString("a15");
                            b.radioButton16.Text = res2.GetString("a16");

                            b.radioButton17.Text = res2.GetString("a17");
                            b.radioButton18.Text = res2.GetString("a18");
                            b.radioButton19.Text = res2.GetString("a19");
                            b.radioButton20.Text = res2.GetString("a20");

                            b.Show();
                            ps.name = "4";
                            ps.Save();


                        }
                        if (textBox1.Text == "4")
                        {
                            b.textBox1.Text = textBox1.Text;

                            b.label1.Text = res1.GetString("a11");
                            b.label2.Text = res1.GetString("a12");
                            b.label3.Text = res1.GetString("a13");
                            b.label4.Text = res1.GetString("a14");
                            b.label5.Text = res1.GetString("a15");

                            b.radioButton1.Text = res2.GetString("a1");
                            b.radioButton2.Text = res2.GetString("a2");
                            b.radioButton3.Text = res2.GetString("a3");
                            b.radioButton4.Text = res2.GetString("a4");

                            b.radioButton5.Text = res2.GetString("a5");
                            b.radioButton6.Text = res2.GetString("a6");
                            b.radioButton7.Text = res2.GetString("a7");
                            b.radioButton8.Text = res2.GetString("a8");

                            b.radioButton9.Text = res2.GetString("a9");
                            b.radioButton10.Text = res2.GetString("a10");
                            b.radioButton11.Text = res2.GetString("a11");
                            b.radioButton12.Text = res2.GetString("a12");

                            b.radioButton13.Text = res2.GetString("a13");
                            b.radioButton14.Text = res2.GetString("a14");
                            b.radioButton15.Text = res2.GetString("a15");
                            b.radioButton16.Text = res2.GetString("a16");

                            b.radioButton17.Text = res2.GetString("a17");
                            b.radioButton18.Text = res2.GetString("a18");
                            b.radioButton19.Text = res2.GetString("a19");
                            b.radioButton20.Text = res2.GetString("a20");

                            b.Show();
                            ps.name = "2";
                            ps.Save();


                        }
                    }
                    if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
                    {
                        Form2 a = new Form2();
                        a.checkBox1.Checked = true;
                        a.checkBox2.Checked = true;
                        a.checkBox3.Checked = true;
                        ResourceManager res = new ResourceManager("online_exam.Properties.Resources", Assembly.GetExecutingAssembly());
                        ResourceManager abc = new ResourceManager("online_exam.abc", Assembly.GetExecutingAssembly());
                        Properties.Settings ps = new Properties.Settings();
                        if (textBox1.Text == "2")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a1");
                            a.label2.Text = res.GetString("a2");
                            a.label3.Text = res.GetString("a3");
                            a.label4.Text = res.GetString("a4");
                            a.label5.Text = res.GetString("a5");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "3";
                            ps.Save();


                        }
                        if (textBox1.Text == "3")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a6");
                            a.label2.Text = res.GetString("a7");
                            a.label3.Text = res.GetString("a8");
                            a.label4.Text = res.GetString("a9");
                            a.label5.Text = res.GetString("a10");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();

                            ps.name = "4";
                            ps.Save();

                        }
                        if (textBox1.Text == "4")
                        {
                            a.textBox1.Text = textBox1.Text;

                            a.label1.Text = res.GetString("a11");
                            a.label2.Text = res.GetString("a12");
                            a.label3.Text = res.GetString("a13");
                            a.label4.Text = res.GetString("a14");
                            a.label5.Text = res.GetString("a15");

                            a.radioButton1.Text = abc.GetString("a1");
                            a.radioButton2.Text = abc.GetString("a2");
                            a.radioButton3.Text = abc.GetString("a3");
                            a.radioButton4.Text = abc.GetString("a4");

                            a.radioButton5.Text = abc.GetString("a5");
                            a.radioButton6.Text = abc.GetString("a6");
                            a.radioButton7.Text = abc.GetString("a7");
                            a.radioButton8.Text = abc.GetString("a8");

                            a.radioButton9.Text = abc.GetString("a9");
                            a.radioButton10.Text = abc.GetString("a10");
                            a.radioButton11.Text = abc.GetString("a11");
                            a.radioButton12.Text = abc.GetString("a12");

                            a.radioButton13.Text = abc.GetString("a13");
                            a.radioButton14.Text = abc.GetString("a14");
                            a.radioButton15.Text = abc.GetString("a15");
                            a.radioButton16.Text = abc.GetString("a16");

                            a.radioButton17.Text = abc.GetString("a17");
                            a.radioButton18.Text = abc.GetString("a18");
                            a.radioButton19.Text = abc.GetString("a19");
                            a.radioButton20.Text = abc.GetString("a20");

                            a.Show();
                            ps.name = "2";
                            ps.Save();

                        }


                    }

                }
                else
                {
                    MessageBox.Show("please select a gender");
                }
            }
            else
            {
                MessageBox.Show("please enter the user name");
            }
        }

           
        
      




        private void Form1_Load(object sender, EventArgs e)
        {

            Properties.Settings ps = new Properties.Settings();
            textBox1.Text = ps.name;
            
        }

       
    }
}
        

        

