﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Reflection;
using System.Resources;
namespace online_exam
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }



        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
           
            
        }
        Form5 d=new Form5();
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
            {
                if (textBox1.Text == "2")
                {
                    if (radioButton1.Checked == true)
                    {
                        d.label5.BackColor = Color.Green;
                    }
                    else { d.label5.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        d.label6.BackColor = Color.Green;
                    }
                    else { d.label6.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        d.label7.BackColor = Color.Green;
                    }
                    else { d.label7.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        d.label8.BackColor = Color.Green;
                    }
                    else { d.label8.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        d.label9.BackColor = Color.Green;
                    }
                    else { d.label9.BackColor = Color.Red; }
                    d.Show();


                }
                if (textBox1.Text == "3")
                {
                    if (radioButton2.Checked == true)
                    {
                        d.label5.BackColor = Color.Green;
                    }
                    else { d.label5.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        d.label6.BackColor = Color.Green;
                    }
                    else { d.label6.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        d.label7.BackColor = Color.Green;
                    }
                    else { d.label7.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        d.label8.BackColor = Color.Green;
                    }
                    else { d.label8.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        d.label9.BackColor = Color.Green;
                    }
                    else { d.label9.BackColor = Color.Red; }

                    d.Show();


                }



                if (textBox1.Text == "4")
                {
                    if (radioButton3.Checked == true)
                    {
                        d.label5.BackColor = Color.Green;
                    }
                    else { d.label5.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        d.label6.BackColor = Color.Green;
                    }
                    else { d.label6.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        d.label7.BackColor = Color.Green;
                    }
                    else { d.label7.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        d.label8.BackColor = Color.Green;
                    }
                    else { d.label8.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        d.label9.BackColor = Color.Green;
                    }
                    else { d.label9.BackColor = Color.Red; }

                    d.Show();


                }

            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
            {

                Form3 b = new Form3();
                b.checkBox1.Checked = true;
                b.checkBox2.Checked = true;
                ResourceManager res1 = new ResourceManager("online_exam.Resource1", Assembly.GetExecutingAssembly());
                ResourceManager res2 = new ResourceManager("online_exam.Resource2", Assembly.GetExecutingAssembly());
                Properties.Settings ps = new Properties.Settings();

                if (textBox1.Text == "2")
                {
                    b.textBox1.Text = textBox1.Text;

                    b.label1.Text = res1.GetString("a1");
                    b.label2.Text = res1.GetString("a2");
                    b.label3.Text = res1.GetString("a3");
                    b.label4.Text = res1.GetString("a4");
                    b.label5.Text = res1.GetString("a5");

                    b.radioButton1.Text = res2.GetString("a1");
                    b.radioButton2.Text = res2.GetString("a2");
                    b.radioButton3.Text = res2.GetString("a3");
                    b.radioButton4.Text = res2.GetString("a4");

                    b.radioButton5.Text = res2.GetString("a5");
                    b.radioButton6.Text = res2.GetString("a6");
                    b.radioButton7.Text = res2.GetString("a7");
                    b.radioButton8.Text = res2.GetString("a8");

                    b.radioButton9.Text = res2.GetString("a9");
                    b.radioButton10.Text = res2.GetString("a10");
                    b.radioButton11.Text = res2.GetString("a11");
                    b.radioButton12.Text = res2.GetString("a12");

                    b.radioButton13.Text = res2.GetString("a13");
                    b.radioButton14.Text = res2.GetString("a14");
                    b.radioButton15.Text = res2.GetString("a15");
                    b.radioButton16.Text = res2.GetString("a16");

                    b.radioButton17.Text = res2.GetString("a17");
                    b.radioButton18.Text = res2.GetString("a18");
                    b.radioButton19.Text = res2.GetString("a19");
                    b.radioButton20.Text = res2.GetString("a20");

                    b.Show();
                    ps.name = "3";
                    ps.Save();

                    if (radioButton1.Checked == true)
                    {
                        b.label6.BackColor = Color.Green;
                    }
                    else { b.label6.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        b.label7.BackColor = Color.Green;
                    }
                    else { b.label7.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        b.label8.BackColor = Color.Green;
                    }
                    else { b.label8.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        b.label9.BackColor = Color.Green;
                    }
                    else { b.label9.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        b.label10.BackColor = Color.Green;
                    }
                    else { b.label10.BackColor = Color.Red; }




                }
                if (textBox1.Text == "3")
                {
                    b.textBox1.Text = textBox1.Text;

                    b.label1.Text = res1.GetString("a6");
                    b.label2.Text = res1.GetString("a7");
                    b.label3.Text = res1.GetString("a8");
                    b.label4.Text = res1.GetString("a9");
                    b.label5.Text = res1.GetString("a10");

                    b.radioButton1.Text = res2.GetString("a1");
                    b.radioButton2.Text = res2.GetString("a2");
                    b.radioButton3.Text = res2.GetString("a3");
                    b.radioButton4.Text = res2.GetString("a4");

                    b.radioButton5.Text = res2.GetString("a5");
                    b.radioButton6.Text = res2.GetString("a6");
                    b.radioButton7.Text = res2.GetString("a7");
                    b.radioButton8.Text = res2.GetString("a8");

                    b.radioButton9.Text = res2.GetString("a9");
                    b.radioButton10.Text = res2.GetString("a10");
                    b.radioButton11.Text = res2.GetString("a11");
                    b.radioButton12.Text = res2.GetString("a12");

                    b.radioButton13.Text = res2.GetString("a13");
                    b.radioButton14.Text = res2.GetString("a14");
                    b.radioButton15.Text = res2.GetString("a15");
                    b.radioButton16.Text = res2.GetString("a16");

                    b.radioButton17.Text = res2.GetString("a17");
                    b.radioButton18.Text = res2.GetString("a18");
                    b.radioButton19.Text = res2.GetString("a19");
                    b.radioButton20.Text = res2.GetString("a20");

                    b.Show();
                    ps.name = "4";
                    ps.Save();
                    if (radioButton2.Checked == true)
                    {
                        b.label6.BackColor = Color.Green;
                    }
                    else { b.label6.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        b.label7.BackColor = Color.Green;
                    }
                    else { b.label7.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        b.label8.BackColor = Color.Green;
                    }
                    else { d.label8.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        b.label9.BackColor = Color.Green;
                    }
                    else { b.label9.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        b.label10.BackColor = Color.Green;
                    }
                    else { b.label10.BackColor = Color.Red; }




                }
                if (textBox1.Text == "4")
                {
                    b.textBox1.Text = textBox1.Text;

                    b.label1.Text = res1.GetString("a11");
                    b.label2.Text = res1.GetString("a12");
                    b.label3.Text = res1.GetString("a13");
                    b.label4.Text = res1.GetString("a14");
                    b.label5.Text = res1.GetString("a15");

                    b.radioButton1.Text = res2.GetString("a1");
                    b.radioButton2.Text = res2.GetString("a2");
                    b.radioButton3.Text = res2.GetString("a3");
                    b.radioButton4.Text = res2.GetString("a4");

                    b.radioButton5.Text = res2.GetString("a5");
                    b.radioButton6.Text = res2.GetString("a6");
                    b.radioButton7.Text = res2.GetString("a7");
                    b.radioButton8.Text = res2.GetString("a8");

                    b.radioButton9.Text = res2.GetString("a9");
                    b.radioButton10.Text = res2.GetString("a10");
                    b.radioButton11.Text = res2.GetString("a11");
                    b.radioButton12.Text = res2.GetString("a12");

                    b.radioButton13.Text = res2.GetString("a13");
                    b.radioButton14.Text = res2.GetString("a14");
                    b.radioButton15.Text = res2.GetString("a15");
                    b.radioButton16.Text = res2.GetString("a16");

                    b.radioButton17.Text = res2.GetString("a17");
                    b.radioButton18.Text = res2.GetString("a18");
                    b.radioButton19.Text = res2.GetString("a19");
                    b.radioButton20.Text = res2.GetString("a20");

                    b.Show();
                    ps.name = "2";
                    ps.Save();
                    if (radioButton3.Checked == true)
                    {
                        b.label6.BackColor = Color.Green;
                    }
                    else { b.label6.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        b.label7.BackColor = Color.Green;
                    }
                    else { b.label7.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        b.label8.BackColor = Color.Green;
                    }
                    else { b.label8.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        b.label9.BackColor = Color.Green;
                    }
                    else { b.label9.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        b.label10.BackColor = Color.Green;
                    }
                    else { b.label10.BackColor = Color.Red; }




                }
            }
                if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
                {
                    Form4 c = new Form4();
                    c.checkBox1.Checked = true;
                    c.checkBox3.Checked = true;
                    ResourceManager res3 = new ResourceManager("online_exam.Resource3", Assembly.GetExecutingAssembly());
                    ResourceManager res4 = new ResourceManager("online_exam.Resource4", Assembly.GetExecutingAssembly());
                    Properties.Settings ps = new Properties.Settings();


                    if (textBox1.Text == "2")
                    {
                        c.textBox1.Text = textBox1.Text;

                        c.label1.Text = res3.GetString("a1");
                        c.label2.Text = res3.GetString("a2");
                        c.label3.Text = res3.GetString("a3");
                        c.label4.Text = res3.GetString("a4");
                        c.label5.Text = res3.GetString("a5");

                        c.radioButton1.Text = res4.GetString("a1");
                        c.radioButton2.Text = res4.GetString("a2");
                        c.radioButton3.Text = res4.GetString("a3");
                        c.radioButton4.Text = res4.GetString("a4");

                        c.radioButton5.Text = res4.GetString("a5");
                        c.radioButton6.Text = res4.GetString("a6");
                        c.radioButton7.Text = res4.GetString("a7");
                        c.radioButton8.Text = res4.GetString("a8");

                        c.radioButton9.Text = res4.GetString("a9");
                        c.radioButton10.Text = res4.GetString("a10");
                        c.radioButton11.Text = res4.GetString("a11");
                        c.radioButton12.Text = res4.GetString("a12");

                        c.radioButton13.Text = res4.GetString("a13");
                        c.radioButton14.Text = res4.GetString("a14");
                        c.radioButton15.Text = res4.GetString("a15");
                        c.radioButton16.Text = res4.GetString("a16");

                        c.radioButton17.Text = res4.GetString("a17");
                        c.radioButton18.Text = res4.GetString("a18");
                        c.radioButton19.Text = res4.GetString("a19");
                        c.radioButton20.Text = res4.GetString("a20");

                       
                        ps.name = "3";
                        ps.Save();

                        if (radioButton1.Checked == true)
                        {
                            c.label6.BackColor = Color.Green;
                        }
                        else { c.label6.BackColor = Color.Red; }

                        if (radioButton5.Checked == true)
                        {
                            c.label7.BackColor = Color.Green;
                        }
                        else { c.label7.BackColor = Color.Red; }

                        if (radioButton9.Checked == true)
                        {
                            c.label8.BackColor = Color.Green;
                        }
                        else { c.label8.BackColor = Color.Red; }

                        if (radioButton13.Checked == true)
                        {
                            c.label9.BackColor = Color.Green;
                        }
                        else { c.label9.BackColor = Color.Red; }

                        if (radioButton17.Checked == true)
                        {
                            c.label10.BackColor = Color.Green;
                        }
                        else { c.label10.BackColor = Color.Red; }

                        c.Show();


                    }
                    if (textBox1.Text == "3")
                    {
                        c.textBox1.Text = textBox1.Text;

                        c.label1.Text = res3.GetString("a6");
                        c.label2.Text = res3.GetString("a7");
                        c.label3.Text = res3.GetString("a8");
                        c.label4.Text = res3.GetString("a9");
                        c.label5.Text = res3.GetString("a10");

                        c.radioButton1.Text = res4.GetString("a1");
                        c.radioButton2.Text = res4.GetString("a2");
                        c.radioButton3.Text = res4.GetString("a3");
                        c.radioButton4.Text = res4.GetString("a4");

                        c.radioButton5.Text = res4.GetString("a5");
                        c.radioButton6.Text = res4.GetString("a6");
                        c.radioButton7.Text = res4.GetString("a7");
                        c.radioButton8.Text = res4.GetString("a8");

                        c.radioButton9.Text = res4.GetString("a9");
                        c.radioButton10.Text = res4.GetString("a10");
                        c.radioButton11.Text = res4.GetString("a11");
                        c.radioButton12.Text = res4.GetString("a12");

                        c.radioButton13.Text = res4.GetString("a13");
                        c.radioButton14.Text = res4.GetString("a14");
                        c.radioButton15.Text = res4.GetString("a15");
                        c.radioButton16.Text = res4.GetString("a16");

                        c.radioButton17.Text = res4.GetString("a17");
                        c.radioButton18.Text = res4.GetString("a18");
                        c.radioButton19.Text = res4.GetString("a19");
                        c.radioButton20.Text = res4.GetString("a20");

                        
                        ps.name = "4";
                        ps.Save();
                        if (radioButton2.Checked == true)
                        {
                            c.label6.BackColor = Color.Green;
                        }
                        else { c.label6.BackColor = Color.Red; }

                        if (radioButton6.Checked == true)
                        {
                            c.label7.BackColor = Color.Green;
                        }
                        else { c.label7.BackColor = Color.Red; }

                        if (radioButton10.Checked == true)
                        {
                            c.label8.BackColor = Color.Green;
                        }
                        else { c.label8.BackColor = Color.Red; }

                        if (radioButton14.Checked == true)
                        {
                            c.label9.BackColor = Color.Green;
                        }
                        else { c.label9.BackColor = Color.Red; }

                        if (radioButton18.Checked == true)
                        {
                            c.label10.BackColor = Color.Green;
                        }
                        else { c.label10.BackColor = Color.Red; }

                        c.Show();
                    }
                    if (textBox1.Text == "4")
                    {
                        c.textBox1.Text = textBox1.Text;

                        c.label1.Text = res3.GetString("a11");
                        c.label2.Text = res3.GetString("a12");
                        c.label3.Text = res3.GetString("a13");
                        c.label4.Text = res3.GetString("a14");
                        c.label5.Text = res3.GetString("a15");

                        c.radioButton1.Text = res4.GetString("a1");
                        c.radioButton2.Text = res4.GetString("a2");
                        c.radioButton3.Text = res4.GetString("a3");
                        c.radioButton4.Text = res4.GetString("a4");

                        c.radioButton5.Text = res4.GetString("a5");
                        c.radioButton6.Text = res4.GetString("a6");
                        c.radioButton7.Text = res4.GetString("a7");
                        c.radioButton8.Text = res4.GetString("a8");

                        c.radioButton9.Text = res4.GetString("a9");
                        c.radioButton10.Text = res4.GetString("a10");
                        c.radioButton11.Text = res4.GetString("a11");
                        c.radioButton12.Text = res4.GetString("a12");

                        c.radioButton13.Text = res4.GetString("a13");
                        c.radioButton14.Text = res4.GetString("a14");
                        c.radioButton15.Text = res4.GetString("a15");
                        c.radioButton16.Text = res4.GetString("a16");

                        c.radioButton17.Text = res4.GetString("a17");
                        c.radioButton18.Text = res4.GetString("a18");
                        c.radioButton19.Text = res4.GetString("a19");
                        c.radioButton20.Text = res4.GetString("a20");

                        c.Show();
                        ps.name = "2";
                        ps.Save();

                        if (radioButton3.Checked == true)
                        {
                            c.label6.BackColor = Color.Green;
                        }
                        else { c.label6.BackColor = Color.Red; }

                        if (radioButton7.Checked == true)
                        {
                            c.label7.BackColor = Color.Green;
                        }
                        else { c.label7.BackColor = Color.Red; }

                        if (radioButton11.Checked == true)
                        {
                            c.label8.BackColor = Color.Green;
                        }
                        else { c.label8.BackColor = Color.Red; }

                        if (radioButton15.Checked == true)
                        {
                            c.label9.BackColor = Color.Green;
                        }
                        else { c.label9.BackColor = Color.Red; }

                        if (radioButton19.Checked == true)
                        {
                            c.label10.BackColor = Color.Green;
                        }
                        else { c.label10.BackColor = Color.Red; }

                    }



                }
                if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
                {
                    Form3 b = new Form3();
                    b.checkBox1.Checked = true;
                    b.checkBox2.Checked = true;
                    b.checkBox3.Checked = true;
                    ResourceManager res1 = new ResourceManager("online_exam.Resource1", Assembly.GetExecutingAssembly());
                    ResourceManager res2 = new ResourceManager("online_exam.Resource2", Assembly.GetExecutingAssembly());
                    Properties.Settings ps = new Properties.Settings();

                    if (textBox1.Text == "2")
                    {
                        b.textBox1.Text = textBox1.Text;

                        b.label1.Text = res1.GetString("a1");
                        b.label2.Text = res1.GetString("a2");
                        b.label3.Text = res1.GetString("a3");
                        b.label4.Text = res1.GetString("a4");
                        b.label5.Text = res1.GetString("a5");

                        b.radioButton1.Text = res2.GetString("a1");
                        b.radioButton2.Text = res2.GetString("a2");
                        b.radioButton3.Text = res2.GetString("a3");
                        b.radioButton4.Text = res2.GetString("a4");

                        b.radioButton5.Text = res2.GetString("a5");
                        b.radioButton6.Text = res2.GetString("a6");
                        b.radioButton7.Text = res2.GetString("a7");
                        b.radioButton8.Text = res2.GetString("a8");

                        b.radioButton9.Text = res2.GetString("a9");
                        b.radioButton10.Text = res2.GetString("a10");
                        b.radioButton11.Text = res2.GetString("a11");
                        b.radioButton12.Text = res2.GetString("a12");

                        b.radioButton13.Text = res2.GetString("a13");
                        b.radioButton14.Text = res2.GetString("a14");
                        b.radioButton15.Text = res2.GetString("a15");
                        b.radioButton16.Text = res2.GetString("a16");

                        b.radioButton17.Text = res2.GetString("a17");
                        b.radioButton18.Text = res2.GetString("a18");
                        b.radioButton19.Text = res2.GetString("a19");
                        b.radioButton20.Text = res2.GetString("a20");

                        b.Show();
                        ps.name = "3";
                        ps.Save();

                        if (radioButton1.Checked == true)
                        {
                            b.label6.BackColor = Color.Green;
                        }
                        else { b.label6.BackColor = Color.Red; }

                        if (radioButton5.Checked == true)
                        {
                            b.label7.BackColor = Color.Green;
                        }
                        else { b.label7.BackColor = Color.Red; }

                        if (radioButton9.Checked == true)
                        {
                            b.label8.BackColor = Color.Green;
                        }
                        else { b.label8.BackColor = Color.Red; }

                        if (radioButton13.Checked == true)
                        {
                            b.label9.BackColor = Color.Green;
                        }
                        else { b.label9.BackColor = Color.Red; }

                        if (radioButton17.Checked == true)
                        {
                            b.label10.BackColor = Color.Green;
                        }
                        else { b.label10.BackColor = Color.Red; }




                    }
                    if (textBox1.Text == "3")
                    {
                        b.textBox1.Text = textBox1.Text;

                        b.label1.Text = res1.GetString("a6");
                        b.label2.Text = res1.GetString("a7");
                        b.label3.Text = res1.GetString("a8");
                        b.label4.Text = res1.GetString("a9");
                        b.label5.Text = res1.GetString("a10");

                        b.radioButton1.Text = res2.GetString("a1");
                        b.radioButton2.Text = res2.GetString("a2");
                        b.radioButton3.Text = res2.GetString("a3");
                        b.radioButton4.Text = res2.GetString("a4");

                        b.radioButton5.Text = res2.GetString("a5");
                        b.radioButton6.Text = res2.GetString("a6");
                        b.radioButton7.Text = res2.GetString("a7");
                        b.radioButton8.Text = res2.GetString("a8");

                        b.radioButton9.Text = res2.GetString("a9");
                        b.radioButton10.Text = res2.GetString("a10");
                        b.radioButton11.Text = res2.GetString("a11");
                        b.radioButton12.Text = res2.GetString("a12");

                        b.radioButton13.Text = res2.GetString("a13");
                        b.radioButton14.Text = res2.GetString("a14");
                        b.radioButton15.Text = res2.GetString("a15");
                        b.radioButton16.Text = res2.GetString("a16");

                        b.radioButton17.Text = res2.GetString("a17");
                        b.radioButton18.Text = res2.GetString("a18");
                        b.radioButton19.Text = res2.GetString("a19");
                        b.radioButton20.Text = res2.GetString("a20");

                        b.Show();
                        ps.name = "4";
                        ps.Save();
                        if (radioButton2.Checked == true)
                        {
                            b.label6.BackColor = Color.Green;
                        }
                        else { b.label6.BackColor = Color.Red; }

                        if (radioButton6.Checked == true)
                        {
                            b.label7.BackColor = Color.Green;
                        }
                        else { b.label7.BackColor = Color.Red; }

                        if (radioButton10.Checked == true)
                        {
                            b.label8.BackColor = Color.Green;
                        }
                        else { d.label8.BackColor = Color.Red; }

                        if (radioButton14.Checked == true)
                        {
                            b.label9.BackColor = Color.Green;
                        }
                        else { b.label9.BackColor = Color.Red; }

                        if (radioButton18.Checked == true)
                        {
                            b.label10.BackColor = Color.Green;
                        }
                        else { b.label10.BackColor = Color.Red; }




                    }
                    if (textBox1.Text == "4")
                    {
                        b.textBox1.Text = textBox1.Text;

                        b.label1.Text = res1.GetString("a11");
                        b.label2.Text = res1.GetString("a12");
                        b.label3.Text = res1.GetString("a13");
                        b.label4.Text = res1.GetString("a14");
                        b.label5.Text = res1.GetString("a15");

                        b.radioButton1.Text = res2.GetString("a1");
                        b.radioButton2.Text = res2.GetString("a2");
                        b.radioButton3.Text = res2.GetString("a3");
                        b.radioButton4.Text = res2.GetString("a4");

                        b.radioButton5.Text = res2.GetString("a5");
                        b.radioButton6.Text = res2.GetString("a6");
                        b.radioButton7.Text = res2.GetString("a7");
                        b.radioButton8.Text = res2.GetString("a8");

                        b.radioButton9.Text = res2.GetString("a9");
                        b.radioButton10.Text = res2.GetString("a10");
                        b.radioButton11.Text = res2.GetString("a11");
                        b.radioButton12.Text = res2.GetString("a12");

                        b.radioButton13.Text = res2.GetString("a13");
                        b.radioButton14.Text = res2.GetString("a14");
                        b.radioButton15.Text = res2.GetString("a15");
                        b.radioButton16.Text = res2.GetString("a16");

                        b.radioButton17.Text = res2.GetString("a17");
                        b.radioButton18.Text = res2.GetString("a18");
                        b.radioButton19.Text = res2.GetString("a19");
                        b.radioButton20.Text = res2.GetString("a20");

                        b.Show();
                        ps.name = "2";
                        ps.Save();
                        if (radioButton3.Checked == true)
                        {
                            b.label6.BackColor = Color.Green;
                        }
                        else { b.label6.BackColor = Color.Red; }

                        if (radioButton7.Checked == true)
                        {
                            b.label7.BackColor = Color.Green;
                        }
                        else { b.label7.BackColor = Color.Red; }

                        if (radioButton11.Checked == true)
                        {
                            b.label8.BackColor = Color.Green;
                        }
                        else { b.label8.BackColor = Color.Red; }

                        if (radioButton15.Checked == true)
                        {
                            b.label9.BackColor = Color.Green;
                        }
                        else { b.label9.BackColor = Color.Red; }

                        if (radioButton19.Checked == true)
                        {
                            b.label10.BackColor = Color.Green;
                        }
                        else { b.label10.BackColor = Color.Red; }




                    }
                }

            
        }


                
                
            


        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        }
        }
    

