﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace online_exam
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(checkBox3.Checked==true&&checkBox1.Checked==false&&checkBox2.Checked==false)
            {
            Form5 d = new Form5();
            if (textBox1.Text == "2")
            {
                if (radioButton1.Checked == true)
                {
                    d.label19.BackColor = Color.Green;
                }
                else { d.label19.BackColor = Color.Red; }

                if (radioButton5.Checked == true)
                {
                    d.label18.BackColor = Color.Green;
                }
                else { d.label18.BackColor = Color.Red; }

                if (radioButton9.Checked == true)
                {
                    d.label17.BackColor = Color.Green;
                }
                else { d.label17.BackColor = Color.Red; }

                if (radioButton13.Checked == true)
                {
                    d.label16.BackColor = Color.Green;
                }
                else { d.label16.BackColor = Color.Red; }

                if (radioButton17.Checked == true)
                {
                    d.label15.BackColor = Color.Green;
                }
                else { d.label15.BackColor = Color.Red; }
                d.Show();


            }
            if (textBox1.Text == "3")
            {
                if (radioButton2.Checked == true)
                {
                    d.label19.BackColor = Color.Green;
                }
                else { d.label19.BackColor = Color.Red; }

                if (radioButton6.Checked == true)
                {
                    d.label18.BackColor = Color.Green;
                }
                else { d.label18.BackColor = Color.Red; }

                if (radioButton10.Checked == true)
                {
                    d.label17.BackColor = Color.Green;
                }
                else { d.label17.BackColor = Color.Red; }

                if (radioButton14.Checked == true)
                {
                    d.label16.BackColor = Color.Green;
                }
                else { d.label16.BackColor = Color.Red; }

                if (radioButton18.Checked == true)
                {
                    d.label15.BackColor = Color.Green;
                }
                else { d.label15.BackColor = Color.Red; }
                d.Show();


            }



            if (textBox1.Text == "4")
            {
                if (radioButton3.Checked == true)
                {
                    d.label19.BackColor = Color.Green;
                }
                else { d.label19.BackColor = Color.Red; }

                if (radioButton7.Checked == true)
                {
                    d.label18.BackColor = Color.Green;
                }
                else { d.label18.BackColor = Color.Red; }

                if (radioButton11.Checked == true)
                {
                    d.label17.BackColor = Color.Green;
                }
                else { d.label17.BackColor = Color.Red; }

                if (radioButton15.Checked == true)
                {
                    d.label16.BackColor = Color.Green;
                }
                else { d.label16.BackColor = Color.Red; }

                if (radioButton19.Checked == true)
                {
                    d.label15.BackColor = Color.Green;
                }
                else { d.label15.BackColor = Color.Red; }
                d.Show();

            }
            }
            if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
            {
                Form5 d = new Form5();
              
                if (textBox1.Text == "2")
                {
                    if (radioButton1.Checked == true)
                    {
                        d.label19.BackColor = Color.Green;
                    }
                    else { d.label19.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        d.label18.BackColor = Color.Green;
                    }
                    else { d.label18.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        d.label17.BackColor = Color.Green;
                    }
                    else { d.label17.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        d.label16.BackColor = Color.Green;
                    }
                    else { d.label16.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        d.label15.BackColor = Color.Green;
                    }
                    else { d.label15.BackColor = Color.Red; }
                    d.Show();

                    d.label5.BackColor = label6.BackColor;
                    d.label6.BackColor = label7.BackColor;
                    d.label7.BackColor = label8.BackColor;
                    d.label8.BackColor = label9.BackColor;
                    d.label9.BackColor = label10.BackColor;


                }
                if (textBox1.Text == "3")
                {
                    if (radioButton2.Checked == true)
                    {
                        d.label19.BackColor = Color.Green;
                    }
                    else { d.label19.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        d.label18.BackColor = Color.Green;
                    }
                    else { d.label18.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        d.label17.BackColor = Color.Green;
                    }
                    else { d.label17.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        d.label16.BackColor = Color.Green;
                    }
                    else { d.label16.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        d.label15.BackColor = Color.Green;
                    }
                    else { d.label15.BackColor = Color.Red; }
                    d.Show();

                    d.label5.BackColor = label6.BackColor;
                    d.label6.BackColor = label7.BackColor;
                    d.label7.BackColor = label8.BackColor;
                    d.label8.BackColor = label9.BackColor;
                    d.label9.BackColor = label10.BackColor;

                }
                if (textBox1.Text == "4")
                {
                    if (radioButton3.Checked == true)
                    {
                        d.label19.BackColor = Color.Green;
                    }
                    else { d.label19.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        d.label18.BackColor = Color.Green;
                    }
                    else { d.label18.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        d.label17.BackColor = Color.Green;
                    }
                    else { d.label17.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        d.label16.BackColor = Color.Green;
                    }
                    else { d.label16.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        d.label15.BackColor = Color.Green;
                    }
                    else { d.label15.BackColor = Color.Red; }
                    d.Show();

                    d.label5.BackColor = label6.BackColor;
                    d.label6.BackColor = label7.BackColor;
                    d.label7.BackColor = label8.BackColor;
                    d.label8.BackColor = label9.BackColor;
                    d.label9.BackColor = label10.BackColor;
                }

            }
            if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form5 d = new Form5();
                if (textBox1.Text == "2")
                {
                    if (radioButton1.Checked == true)
                    {
                        d.label19.BackColor = Color.Green;
                    }
                    else { d.label19.BackColor = Color.Red; }

                    if (radioButton5.Checked == true)
                    {
                        d.label18.BackColor = Color.Green;
                    }
                    else { d.label18.BackColor = Color.Red; }

                    if (radioButton9.Checked == true)
                    {
                        d.label17.BackColor = Color.Green;
                    }
                    else { d.label17.BackColor = Color.Red; }

                    if (radioButton13.Checked == true)
                    {
                        d.label16.BackColor = Color.Green;
                    }
                    else { d.label16.BackColor = Color.Red; }

                    if (radioButton17.Checked == true)
                    {
                        d.label15.BackColor = Color.Green;
                    }
                    else { d.label15.BackColor = Color.Red; }
                    d.Show();

                    d.label14.BackColor = label15.BackColor;
                    d.label13.BackColor = label14.BackColor;
                    d.label12.BackColor = label13.BackColor;
                    d.label11.BackColor = label12.BackColor;
                    d.label10.BackColor = label11.BackColor;
                }
                if (textBox1.Text == "3")
                {
                    if (radioButton2.Checked == true)
                    {
                        d.label19.BackColor = Color.Green;
                    }
                    else { d.label19.BackColor = Color.Red; }

                    if (radioButton6.Checked == true)
                    {
                        d.label18.BackColor = Color.Green;
                    }
                    else { d.label18.BackColor = Color.Red; }

                    if (radioButton10.Checked == true)
                    {
                        d.label17.BackColor = Color.Green;
                    }
                    else { d.label17.BackColor = Color.Red; }

                    if (radioButton14.Checked == true)
                    {
                        d.label16.BackColor = Color.Green;
                    }
                    else { d.label16.BackColor = Color.Red; }

                    if (radioButton18.Checked == true)
                    {
                        d.label15.BackColor = Color.Green;
                    }
                    else { d.label15.BackColor = Color.Red; }
                    d.Show();
                    d.label14.BackColor = label15.BackColor;
                    d.label13.BackColor = label14.BackColor;
                    d.label12.BackColor = label13.BackColor;
                    d.label11.BackColor = label12.BackColor;
                    d.label10.BackColor = label11.BackColor;


                }



                if (textBox1.Text == "4")
                {
                    if (radioButton3.Checked == true)
                    {
                        d.label19.BackColor = Color.Green;
                    }
                    else { d.label19.BackColor = Color.Red; }

                    if (radioButton7.Checked == true)
                    {
                        d.label18.BackColor = Color.Green;
                    }
                    else { d.label18.BackColor = Color.Red; }

                    if (radioButton11.Checked == true)
                    {
                        d.label17.BackColor = Color.Green;
                    }
                    else { d.label17.BackColor = Color.Red; }

                    if (radioButton15.Checked == true)
                    {
                        d.label16.BackColor = Color.Green;
                    }
                    else { d.label16.BackColor = Color.Red; }

                    if (radioButton19.Checked == true)
                    {
                        d.label15.BackColor = Color.Green;
                    }
                    else { d.label15.BackColor = Color.Red; }

                    d.Show(); 
                    d.label14.BackColor = label15.BackColor;
                    d.label13.BackColor = label14.BackColor;
                    d.label12.BackColor = label13.BackColor;
                    d.label11.BackColor = label12.BackColor;
                    d.label10.BackColor = label11.BackColor;

                }
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                  Form5 d = new Form5();
            if (textBox1.Text == "2")
            {
                if (radioButton1.Checked == true)
                {
                    d.label19.BackColor = Color.Green;
                }
                else { d.label19.BackColor = Color.Red; }

                if (radioButton5.Checked == true)
                {
                    d.label18.BackColor = Color.Green;
                }
                else { d.label18.BackColor = Color.Red; }

                if (radioButton9.Checked == true)
                {
                    d.label17.BackColor = Color.Green;
                }
                else { d.label17.BackColor = Color.Red; }

                if (radioButton13.Checked == true)
                {
                    d.label16.BackColor = Color.Green;
                }
                else { d.label16.BackColor = Color.Red; }

                if (radioButton17.Checked == true)
                {
                    d.label15.BackColor = Color.Green;
                }
                else { d.label15.BackColor = Color.Red; }
                d.Show();

                d.label5.BackColor = label6.BackColor;
                d.label6.BackColor = label7.BackColor;
                d.label7.BackColor = label8.BackColor;
                d.label8.BackColor = label9.BackColor;
                d.label9.BackColor = label10.BackColor;

                d.label14.BackColor = label15.BackColor;
                d.label13.BackColor = label14.BackColor;
                d.label12.BackColor = label13.BackColor;
                d.label11.BackColor = label12.BackColor;
                d.label10.BackColor = label11.BackColor;
               


            }
            if (textBox1.Text == "3")
            {
                if (radioButton2.Checked == true)
                {
                    d.label19.BackColor = Color.Green;
                }
                else { d.label19.BackColor = Color.Red; }

                if (radioButton6.Checked == true)
                {
                    d.label18.BackColor = Color.Green;
                }
                else { d.label18.BackColor = Color.Red; }

                if (radioButton10.Checked == true)
                {
                    d.label17.BackColor = Color.Green;
                }
                else { d.label17.BackColor = Color.Red; }

                if (radioButton14.Checked == true)
                {
                    d.label16.BackColor = Color.Green;
                }
                else { d.label16.BackColor = Color.Red; }

                if (radioButton18.Checked == true)
                {
                    d.label15.BackColor = Color.Green;
                }
                else { d.label15.BackColor = Color.Red; }
                d.Show();

                d.label5.BackColor = label6.BackColor;
                d.label6.BackColor = label7.BackColor;
                d.label7.BackColor = label8.BackColor;
                d.label8.BackColor = label9.BackColor;
                d.label9.BackColor = label10.BackColor;

                d.label14.BackColor = label15.BackColor;
                d.label13.BackColor = label14.BackColor;
                d.label12.BackColor = label13.BackColor;
                d.label11.BackColor = label12.BackColor;
                d.label10.BackColor = label11.BackColor;
            }



            if (textBox1.Text == "4")
            {
                if (radioButton3.Checked == true)
                {
                    d.label19.BackColor = Color.Green;
                }
                else { d.label19.BackColor = Color.Red; }

                if (radioButton7.Checked == true)
                {
                    d.label18.BackColor = Color.Green;
                }
                else { d.label18.BackColor = Color.Red; }

                if (radioButton11.Checked == true)
                {
                    d.label17.BackColor = Color.Green;
                }
                else { d.label17.BackColor = Color.Red; }

                if (radioButton15.Checked == true)
                {
                    d.label16.BackColor = Color.Green;
                }
                else { d.label16.BackColor = Color.Red; }

                if (radioButton19.Checked == true)
                {
                    d.label15.BackColor = Color.Green;
                }
                else { d.label15.BackColor = Color.Red; }
                d.Show();
                d.label5.BackColor = label6.BackColor;
                d.label6.BackColor = label7.BackColor;
                d.label7.BackColor = label8.BackColor;
                d.label8.BackColor = label9.BackColor;
                d.label9.BackColor = label10.BackColor;

                d.label14.BackColor = label15.BackColor;
                d.label13.BackColor = label14.BackColor;
                d.label12.BackColor = label13.BackColor;
                d.label11.BackColor = label12.BackColor;
                d.label10.BackColor = label11.BackColor;
            }    
            }


            }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
