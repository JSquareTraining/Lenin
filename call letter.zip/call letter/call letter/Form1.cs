﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace call_letter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text.Replace("name", textBox1.Text);
            richTextBox1.Text = richTextBox1.Text.Replace("qualification", textBox6.Text);
            richTextBox1.Text = richTextBox1.Text.Replace("address", textBox4.Text);
            richTextBox1.Text = richTextBox1.Text.Replace("city", textBox5.Text);
            richTextBox1.Text = richTextBox1.Text.Replace("date", textBox3.Text);
            if (radioButton1.Checked == true)
            {
                richTextBox1.Text = richTextBox1.Text.Replace("gender", "Mr.");
            }
            else
            {
                 richTextBox1.Text=richTextBox1.Text.Replace("gender","Mrs.");
            }
            richTextBox1.Text = richTextBox1.Text.Replace("design", textBox7.Text);
            richTextBox1.Text = richTextBox1.Text.Replace("sal", textBox8.Text);
            richTextBox1.Text = richTextBox1.Text.Replace("join", textBox9.Text);


        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //private void Form1_Load(object sender, EventArgs e)
        //{

        //}
    }
}
