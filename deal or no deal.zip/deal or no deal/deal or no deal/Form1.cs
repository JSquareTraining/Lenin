﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deal_or_no_deal
{
    public partial class REGISTRATION : Form
    {
        public REGISTRATION()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
           
        }

        private void REGISTRATION_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (radioButton1.Checked == true || radioButton2.Checked == true)
                {
                    if (comboBox1.Text != "")
                    {
                        choice a = new choice();
                        a.Show();
                    }
                    else
                    {
                        MessageBox.Show("Please select your city");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the gender");

                }
            }
            else if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter your name");
            }
        }
        }
    }

