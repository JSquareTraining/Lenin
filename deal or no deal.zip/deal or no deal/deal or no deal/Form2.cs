﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deal_or_no_deal
{
    public partial class choice : Form
    {
        public choice()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                Form3 b = new Form3();
                b.Show();
            }
            else
            {
                MessageBox.Show("SORRY YOU SELECTED A WRONG ANSWER......BYE!!!!!!!!!!!!!!!");
                Application.Exit();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (radioButton8.Checked == true)
            {
                Form3 b = new Form3();
                b.Show();
            }
            else
            {
                MessageBox.Show("SORRY YOU SELECTED A WRONG ANSWER......BYE!!!!!!!!!!!!!!!");
                Application.Exit();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (radioButton12.Checked == true)
            {
                Form3 b = new Form3();
                b.Show();
            }
            else
            {
                MessageBox.Show("SORRY YOU SELECTED A WRONG ANSWER......BYE!!!!!!!!!!!!!!!");
                Application.Exit();
            }
        }
    }
}
