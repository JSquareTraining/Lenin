﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace deal_or_no_deal
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Properties.Settings ps = new Properties.Settings();
        ResourceManager res = new ResourceManager("deal_or_no_deal.Properties.Resources", Assembly.GetExecutingAssembly());
        Form4 c = new Form4();
        int i = 1;

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label48_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label48.Image;
                    label48.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    label48.Visible = false;
                    label15.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();

                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label48.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    ps.a = "2";
                    ps.Save();

                }

                if (label13.Text == "17")
                {

                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label48.Image;
                    label48.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    label48.Visible = false;
                    label22.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();

                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label48.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    ps.a = "3";
                    ps.Save();

                }

                if (label13.Text == "17")
                {

                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label48.Image;
                    label48.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    label48.Visible = false;
                    label25.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();

                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label48.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    ps.a = "1";
                    ps.Save();

                }

                if (label13.Text == "17")
                {

                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label55_Click(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label31.Image;
                    label31.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    label31.Visible = false;
                    label2.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label31.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    ps.a = "2";
                    ps.Save();
                }
               
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();

                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }

            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label31.Image;
                    label31.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    label31.Visible = false;
                    label16.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label31.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    ps.a = "3";
                    ps.Save();
                }

                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();

                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label31.Image;
                    label31.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    label31.Visible = false;
                    label1.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label31.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    ps.a = "1";
                    ps.Save();
                }

                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();

                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label27_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label27.Image;
                    label27.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    label27.Visible = false;
                    label4.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label27.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }




            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label27.Image;
                    label27.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    label27.Visible = false;
                    label11.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label27.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }




            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label27.Image;
                    label27.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    label27.Visible = false;
                    label6.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label27.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }


            }
        }

        private void label28_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label28.Image;
                    label28.Visible = false;
                    label53.Enabled = false; label70.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    label28.Visible = false;
                    label25.Enabled = false; label70.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label28.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }

            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label28.Image;
                    label28.Visible = false;
                    label53.Enabled = false; label70.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage =Image.FromFile(@" C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    label28.Visible = false;
                    label24.Enabled = false; 
                    label70.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label28.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@" C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label28.Image;
                    label28.Visible = false;
                    label53.Enabled = false; label70.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    label28.Visible = false;
                    label11.Enabled = false; label70.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label28.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label29_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label29.Image;
                    label29.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {

                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    label29.Visible = false;
                    label5.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label29.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label29.Image;
                    label29.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {

                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    label29.Visible = false;
                    label19.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label29.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label29.Image;
                    label29.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {

                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    label29.Visible = false;
                    label24.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label29.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label30_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label30.Image;
                    label30.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    label30.Visible = false;
                    label21.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label30.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label30.Image;
                    label30.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    label30.Visible = false;
                    label12.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label30.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label30.Image;
                    label30.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    label30.Visible = false;
                    label18.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label30.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label36_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label36.Image;
                    label36.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    label36.Visible = false;
                    label6.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label36.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }

            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label36.Image;
                    label36.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    label36.Visible = false;
                    label26.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label36.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label36.Image;
                    label36.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    label36.Visible = false;
                    label7.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label36.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label35_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label35.Image;
                    label35.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    label35.Visible = false;
                    label22.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label35.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label35.Image;
                    label35.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    label35.Visible = false;
                    label15.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label35.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label35.Image;
                    label35.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    label35.Visible = false;
                    label12.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label35.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }


        private void label34_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label34.Image;
                    label34.Visible = false;
                    label53.Enabled = false; label68.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    label34.Visible = false;
                    label17.Enabled = false; label68.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label34.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            
if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label34.Image;
                    label34.Visible = false;
                    label53.Enabled = false; label68.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    label34.Visible = false;
                    label23.Enabled = false; label68.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label34.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
if (label71.Text == "3")
{
    if (label13.Text == "25")
    {
        label53.Image = label34.Image;
        label34.Visible = false;
        label53.Enabled = false; label68.Text = "1";
        int j = Convert.ToInt32(label13.Text);
        int k = j - i;
        label13.Text = k.ToString();
    }
    else if (label13.Text != "25" && label53.Enabled == false)
    {
        label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
        label34.Visible = false;
        label23.Enabled = false; label68.Text = "1";
        int j = Convert.ToInt32(label13.Text);
        int k = j - i;
        label13.Text = k.ToString();
    }
    if (label13.Text != "25" && label53.Enabled == true)
    {
        label53.Visible = false;
        label34.Visible = false;
        panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
        ps.a = "1";
        ps.Save();
    }
    if (label13.Text == "17")
    {
        Form4 c = new Form4();
        c.label64.Text = label64.Text;
        c.label65.Text = label65.Text;
        c.label66.Text = label66.Text;
        c.label67.Text = label67.Text;
        c.label68.Text = label68.Text;
        c.label69.Text = label69.Text;
        c.label70.Text = label70.Text;
        c.label4.Text = label13.Text;
        c.Show();
    }
    if (label13.Text == "12")
    {
        Form4 c = new Form4();
        c.label64.Text = label64.Text;
        c.label65.Text = label65.Text;
        c.label66.Text = label66.Text;
        c.label67.Text = label67.Text;
        c.label68.Text = label68.Text;
        c.label69.Text = label69.Text;
        c.label70.Text = label70.Text;
        c.label4.Text = label13.Text;
        c.Show();
    }
    if (label13.Text == "8")
    {
        Form4 c = new Form4();
        c.label64.Text = label64.Text;
        c.label65.Text = label65.Text;
        c.label66.Text = label66.Text;
        c.label67.Text = label67.Text;
        c.label68.Text = label68.Text;
        c.label69.Text = label69.Text;
        c.label70.Text = label70.Text;
        c.label4.Text = label13.Text;
        c.Show();
    }
    if (label13.Text == "4")
    {
        Form4 c = new Form4();
        c.label64.Text = label64.Text;
        c.label65.Text = label65.Text;
        c.label66.Text = label66.Text;
        c.label67.Text = label67.Text;
        c.label68.Text = label68.Text;
        c.label69.Text = label69.Text;
        c.label70.Text = label70.Text;
        c.label4.Text = label13.Text;
        c.Show();
    }
    if (label13.Text == "2")
    {
        Form4 c = new Form4();

        c.label64.Text = label64.Text;
        c.label65.Text = label65.Text;
        c.label66.Text = label66.Text;
        c.label67.Text = label67.Text;
        c.label68.Text = label68.Text;
        c.label69.Text = label69.Text;
        c.label70.Text = label70.Text;
        c.label4.Text = label13.Text;
        c.Show();
    }
    if (label13.Text == "1" && label53.Enabled == false)
    {
        Form4 c = new Form4();
        label53.Enabled = true;
        c.label64.Text = label64.Text;
        c.label65.Text = label65.Text;
        c.label66.Text = label66.Text;
        c.label67.Text = label67.Text;
        c.label68.Text = label68.Text;
        c.label69.Text = label69.Text;
        c.label70.Text = label70.Text;
        c.label4.Text = label13.Text;
        c.Show();
        MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
    }

}
        }

        private void label33_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label33.Image;
                    label33.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    label33.Visible = false;
                    label7.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label33.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label33.Image;
                    label33.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    label33.Visible = false;
                    label14.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label33.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } 
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label33.Image;
                    label33.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    label33.Visible = false;
                    label22.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label33.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } 
        }

        private void label32_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label32.Image;
                    label32.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    label32.Visible = false;
                    label1.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label32.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label32.Image;
                    label32.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    label32.Visible = false;
                    label10.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label32.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }

            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label32.Image;
                    label32.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    label32.Visible = false;
                    label2.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label32.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label41_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label41.Image;
                    label41.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    label41.Visible = false;
                    label8.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label41.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label41.Image;
                    label41.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    label41.Visible = false;
                    label18.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label41.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label41.Image;
                    label41.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    label41.Visible = false;
                    label8.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label41.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label40_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label40.Image;
                    label40.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    label40.Visible = false;
                    label3.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label40.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {

                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label40.Image;
                    label40.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    label40.Visible = false;
                    label9.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label40.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {

                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label40.Image;
                    label40.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    label40.Visible = false;
                    label14.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label40.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {

                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label39_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label39.Image;
                    label39.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    label39.Visible = false;
                    label20.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label39.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label39.Image;
                    label39.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    label39.Visible = false;
                    label20.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label39.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label39.Image;
                    label39.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    label39.Visible = false;
                    label21.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label39.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label38_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label38.Image;
                    label38.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    label38.Visible = false;
                    label9.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label38.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label38.Image;
                    label38.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    label38.Visible = false;
                    label3.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label38.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label38.Image;
                    label38.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    label38.Visible = false;
                    label17.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label38.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label37_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label37.Image;
                    label37.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    label37.Visible = false;
                    label18.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label37.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label37.Image;
                    label37.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    label37.Visible = false;
                    label8.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label37.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label37.Image;
                    label37.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    label37.Visible = false;
                    label3.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label37.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label51_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label51.Image;
                    label51.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    label51.Visible = false;
                    label10.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label51.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label51.Image;
                    label51.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    label51.Visible = false;
                    label1.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label51.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label51.Image;
                    label51.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    label51.Visible = false;
                    label9.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label51.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label50_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label50.Image;
                    label50.Visible = false;
                    label53.Enabled = false;
                    label64.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    label50.Visible = false;
                    label14.Enabled = false;
                    label64.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label50.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label50.Image;
                    label50.Visible = false;
                    label53.Enabled = false;
                    label64.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    label50.Visible = false;
                    label7.Enabled = false;
                    label64.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label50.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label50.Image;
                    label50.Visible = false;
                    label53.Enabled = false;
                    label64.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    label50.Visible = false;
                    label15.Enabled = false;
                    label64.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label50.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }


        private void label49_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label49.Image;
                    label49.Visible = false;
                    label53.Enabled = false; label66.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    label49.Visible = false;
                    label23.Enabled = false; label66.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label49.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label49.Image;
                    label49.Visible = false;
                    label53.Enabled = false; label66.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    label49.Visible = false;
                    label17.Enabled = false; label66.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label49.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label49.Image;
                    label49.Visible = false;
                    label53.Enabled = false; label66.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    label49.Visible = false;
                    label20.Enabled = false; label66.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label49.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label47_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label47.Image;
                    label47.Visible = false;
                    label53.Enabled = false; label69.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    label47.Visible = false;
                    label26.Enabled = false; label69.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label47.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label47.Image;
                    label47.Visible = false;
                    label53.Enabled = false; label69.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    label47.Visible = false;
                    label6.Enabled = false; label69.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label47.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label47.Image;
                    label47.Visible = false;
                    label53.Enabled = false; label69.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    label47.Visible = false;
                    label4.Enabled = false; 
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label47.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label46_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label46.Image;
                    label46.Visible = false;
                    label53.Enabled = false;
                    label65.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    label46.Visible = false;
                    label16.Enabled = false;
                    label65.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label46.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label46.Image;
                    label46.Visible = false;
                    label53.Enabled = false;
                    label65.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    label46.Visible = false;
                    label2.Enabled = false;
                    label65.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label46.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
             if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label46.Image;
                    label46.Visible = false;
                    label53.Enabled = false;
                    label65.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    label46.Visible = false;
                    label10.Enabled = false;
                  
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label46.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label45_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label45.Image;
                    label45.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    label45.Visible = false;
                    label12.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label45.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label45.Image;
                    label45.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    label45.Visible = false;
                    label21.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label45.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label45.Image;
                    label45.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    label45.Visible = false;
                    label16.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label45.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label44_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label44.Image;
                    label44.Visible = false;
                    label53.Enabled = false; label67.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    label44.Visible = false;
                    label19.Enabled = false; label67.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label44.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label44.Image;
                    label44.Visible = false;
                    label53.Enabled = false; label67.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    label44.Visible = false;
                    label5.Enabled = false; 
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label44.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label44.Image;
                    label44.Visible = false;
                    label53.Enabled = false; label67.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    label44.Visible = false;
                    label19.Enabled = false; label67.Text = "1";
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label44.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    ps.a ="1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label43_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label43.Image;
                    label43.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    label43.Visible = false;
                    label24.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label43.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label43.Image;
                    label43.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    label43.Visible = false;
                    label25.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label43.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            } 
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label43.Image;
                    label43.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    label43.Visible = false;
                    label26.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label43.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label42_Click(object sender, EventArgs e)
        {

            if (label71.Text == "1")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label42.Image;
                    label42.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    label42.Visible = false;
                    label11.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label42.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    ps.a = "2";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }

            if (label71.Text == "2")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label42.Image;
                    label42.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    label42.Visible = false;
                    label4.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label42.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    ps.a = "3";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
            if (label71.Text == "3")
            {
                if (label13.Text == "25")
                {
                    label53.Image = label42.Image;
                    label42.Visible = false;
                    label53.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                else if (label13.Text != "25" && label53.Enabled == false)
                {
                    label54.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    label42.Visible = false;
                    label5.Enabled = false;
                    int j = Convert.ToInt32(label13.Text);
                    int k = j - i;
                    label13.Text = k.ToString();
                }
                if (label13.Text != "25" && label53.Enabled == true)
                {
                    label53.Visible = false;
                    label42.Visible = false;
                    panel1.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    ps.a = "1";
                    ps.Save();
                }
                if (label13.Text == "17")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "12")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "8")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "4")
                {
                    Form4 c = new Form4();
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "2")
                {
                    Form4 c = new Form4();

                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                }
                if (label13.Text == "1" && label53.Enabled == false)
                {
                    Form4 c = new Form4();
                    label53.Enabled = true;
                    c.label64.Text = label64.Text;
                    c.label65.Text = label65.Text;
                    c.label66.Text = label66.Text;
                    c.label67.Text = label67.Text;
                    c.label68.Text = label68.Text;
                    c.label69.Text = label69.Text;
                    c.label70.Text = label70.Text;
                    c.label4.Text = label13.Text;
                    c.Show();
                    MessageBox.Show("PLEASE SELECT ANY ONE BOX ...LUCKY BOX OR YOUR REMAINING BOX");
                }

            }
        }

        private void label53_Click(object sender, EventArgs e)
        {
            if (label71.Text == "1")
            {
                Form5 d = new Form5();
                if (label53.Image == label27.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");

                    d.Show();
                }

                if (label53.Image == label28.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    d.Show();
                }

                if (label53.Image == label29.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    d.Show();
                }

                if (label53.Image == label30.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    d.Show();
                }

                if (label53.Image == label31.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob11.jpg");
                    d.Show();
                }

                if (label53.Image == label36.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    d.Show();
                }

                if (label53.Image == label35.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    d.Show();
                }

                if (label53.Image == label34.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    d.Show();
                }

                if (label53.Image == label33.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    d.Show();
                }

                if (label53.Image == label32.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    d.Show();
                }
                if (label53.Image == label41.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    d.Show();
                }

                if (label53.Image == label40.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    d.Show();
                }

                if (label53.Image == label39.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    d.Show();
                }

                if (label53.Image == label38.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    d.Show();
                }

                if (label53.Image == label37.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    d.Show();
                }
                if (label53.Image == label51.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    d.Show();
                }

                if (label53.Image == label50.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    d.Show();
                }

                if (label53.Image == label49.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    d.Show();
                }

                if (label53.Image == label48.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    d.Show();
                }

                if (label53.Image == label47.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    d.Show();
                }
                if (label53.Image == label46.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    d.Show();
                }

                if (label53.Image == label45.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    d.Show();
                }

                if (label53.Image == label44.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    d.Show();
                }

                if (label53.Image == label43.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    d.Show();
                }

                if (label53.Image == label42.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    d.Show();
                }
                ps.a = "2";
                ps.Save();
                Form3 b = new Form3();
                b.Close();
            }
            if (label71.Text == "2")
            {
                Form5 d = new Form5();
                if (label53.Image == label27.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");

                    d.Show();
                }

                if (label53.Image == label28.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    d.Show();
                }

                if (label53.Image == label29.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    d.Show();
                }

                if (label53.Image == label30.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500.jpg");
                    d.Show();
                }

                if (label53.Image == label31.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob40000.jpg");
                    d.Show();
                }

                if (label53.Image == label36.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    d.Show();
                }

                if (label53.Image == label35.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b5000.jpg");
                    d.Show();
                }

                if (label53.Image == label34.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    d.Show();
                }

                if (label53.Image == label33.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    d.Show();
                }

                if (label53.Image == label32.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    d.Show();
                }
                if (label53.Image == label41.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    d.Show();
                }

                if (label53.Image == label40.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    d.Show();
                }

                if (label53.Image == label39.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    d.Show();
                }

                if (label53.Image == label38.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    d.Show();
                }

                if (label53.Image == label37.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    d.Show();
                }
                if (label53.Image == label51.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    d.Show();
                }

                if (label53.Image == label50.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    d.Show();
                }

                if (label53.Image == label49.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    d.Show();
                }

                if (label53.Image == label48.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b75000.jpg");
                    d.Show();
                }

                if (label53.Image == label47.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");
                    d.Show();
                }
                if (label53.Image == label46.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1.jpg");
                    d.Show();
                }

                if (label53.Image == label45.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    d.Show();
                }

                if (label53.Image == label44.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    d.Show();
                }

                if (label53.Image == label43.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    d.Show();
                }

                if (label53.Image == label42.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    d.Show();
                }
                ps.a = "3";
                ps.Save();
                Form3 b = new Form3();
                b.Close();
            } 
            if (label71.Text == "3")
            {
                Form5 d = new Form5();
                if (label53.Image == label27.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50.jpg");

                    d.Show();
                }

                if (label53.Image == label28.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400.jpg");
                    d.Show();
                }

                if (label53.Image == label29.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25000.jpg");
                    d.Show();
                }

                if (label53.Image == label30.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob400000.jpg");
                    d.Show();
                }

                if (label53.Image == label31.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    d.Show();
                }

                if (label53.Image == label36.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob75.jpg");
                    d.Show();
                }

                if (label53.Image == label35.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\0b500.jpg");
                    d.Show();
                }

                if (label53.Image == label34.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob50000.jpg");
                    d.Show();
                }

                if (label53.Image == label33.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob750000.jpg");
                    d.Show();
                }

                if (label53.Image == label32.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\OB1.jpg");
                    d.Show();
                }
                if (label53.Image == label41.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100.jpg");
                    d.Show();
                }

                if (label53.Image == label40.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000.jpg");
                    d.Show();
                }

                if (label53.Image == label39.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob100000.jpg");
                    d.Show();
                }

                if (label53.Image == label38.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob500000.jpg");
                    d.Show();
                }

                if (label53.Image == label37.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5.jpg");
                    d.Show();
                }
                if (label53.Image == label51.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200.jpg");
                    d.Show();
                }

                if (label53.Image == label50.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob5000.jpg");
                    d.Show();
                }

                if (label53.Image == label49.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob200000.jpg");
                    d.Show();
                }

                if (label53.Image == label48.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob1000000.jpg");
                    d.Show();
                }

                if (label53.Image == label47.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10.jpg");
                    d.Show();
                }
                if (label53.Image == label46.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300.jpg");
                    d.Show();
                }

                if (label53.Image == label45.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob10000.jpg");
                    d.Show();
                }

                if (label53.Image == label44.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob300000.jpg");
                    d.Show();
                }

                if (label53.Image == label43.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob.jpg");
                    d.Show();
                }

                if (label53.Image == label42.Image)
                {
                    d.BackgroundImage = Image.FromFile(@"C:\Users\leni\Desktop\New folder (2)\New folder (2)\ob25.jpg");
                    d.Show();
                }
                ps.a = "1";
                ps.Save();
                Form3 b = new Form3();
                b.Close();
            }
           
           
                


        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Properties.Settings ps = new Properties.Settings();
            label71.Text = ps.a;

        }
    }

}

