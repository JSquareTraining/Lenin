﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deal_or_no_deal
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 b = new Form3();
            b.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            if (label4.Text == "17")
            {
                if (label64.Text == "1")
                {
                    if (label65.Text == "1")
                    {
                        if (label66.Text == "1")
                        {
                            if (label67.Text == "1")
                            {
                                if (label68.Text == "1")
                                {
                                    if (label69.Text == "1")
                                    {
                                        if (label70.Text == "1")
                                        {
                                            label3.Text = "Rs.20,000";
                                        }
                                        else 
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }
                                        
                                    }
                                    else 
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }
                                }
                                else
                                {
                                    label3.Text = "Rs.2,20,000";
                                }
                               
                            }
                            else
                            {
                                label3.Text = "Rs.5,20,000";
                            }
                               

                        }
                        else
                        {
                            label3.Text = "Rs.20,000";
                        }


                    }
                    else
                    {
                        label3.Text = "Rs.5,000";
                    }
                }
                else
                {
                    label3.Text = "Rs.5,000";
                }
            }
            if (label4.Text == "12")
            {
                if (label64.Text == "1")
                {
                    if (label65.Text == "1")
                    {
                        if (label66.Text == "1")
                        {
                            if (label67.Text == "1")
                            {
                                if (label68.Text == "1")
                                {
                                    if (label69.Text == "1")
                                    {
                                        if (label70.Text == "1")
                                        {
                                            label3.Text = "Rs.20,000";
                                        }
                                        else
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }

                                    }
                                    else
                                    {
                                        label3.Text = "Rs.7,65,432";
                                    }
                                }
                                else
                                {
                                    label3.Text = "Rs.2,20,000";
                                }

                            }
                            else
                            {
                                label3.Text = "Rs.5,20,000";
                            }


                        }
                        else
                        {
                            label3.Text = "Rs.20,000";
                        }


                    }
                    else
                    {
                        label3.Text = "Rs.5,000";
                    }
                }
                else
                {
                    label3.Text = "Rs.5,000";
                }
            }
            if (label4.Text == "8")
            {
                if (label64.Text == "1")
                {
                    if (label65.Text == "1")
                    {
                        if (label66.Text == "1")
                        {
                            if (label67.Text == "1")
                            {
                                if (label68.Text == "1")
                                {
                                    if (label69.Text == "1")
                                    {
                                        if (label70.Text == "1")
                                        {
                                            label3.Text = "Rs.20,000";
                                        }
                                        else
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }

                                    }
                                    else
                                    {
                                        label3.Text = "Rs.7,65,432";
                                    }
                                }
                                else
                                {
                                    label3.Text = "Rs.2,20,000";
                                }

                            }
                            else
                            {
                                label3.Text = "Rs.5,20,000";
                            }


                        }
                        else
                        {
                            label3.Text = "Rs.20,000";
                        }


                    }
                    else
                    {
                        label3.Text = "Rs.5,000";
                    }
                }
                else
                {
                    label3.Text = "Rs.5,000";
                }
            }
            if (label4.Text == "4")
            {
                if (label64.Text == "1")
                {
                    if (label65.Text == "1")
                    {
                        if (label66.Text == "1")
                        {
                            if (label67.Text == "1")
                            {
                                if (label68.Text == "1")
                                {
                                    if (label69.Text == "1")
                                    {
                                        if (label70.Text == "1")
                                        {
                                            label3.Text = "Rs.20,000";
                                        }
                                        else
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }

                                    }
                                    else
                                    {
                                        label3.Text = "Rs.7,65,432";
                                    }
                                }
                                else
                                {
                                    label3.Text = "Rs.2,20,000";
                                }

                            }
                            else
                            {
                                label3.Text = "Rs.5,20,000";
                            }


                        }
                        else
                        {
                            label3.Text = "Rs.20,000";
                        }


                    }
                    else
                    {
                        label3.Text = "Rs.5,000";
                    }
                }
                else
                {
                    label3.Text = "Rs.5,000";
                }
            }
            if (label4.Text == "2")
            {
                if (label64.Text == "1")
                {
                    if (label65.Text == "1")
                    {
                        if (label66.Text == "1")
                        {
                            if (label67.Text == "1")
                            {
                                if (label68.Text == "1")
                                {
                                    if (label69.Text == "1")
                                    {
                                        if (label70.Text == "1")
                                        {
                                            label3.Text = "Rs.20,000";
                                        }
                                        else
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }

                                    }
                                    else
                                    {
                                        label3.Text = "Rs.7,65,432";
                                    }
                                }
                                else
                                {
                                    label3.Text = "Rs.2,20,000";
                                }

                            }
                            else
                            {
                                label3.Text = "Rs.5,20,000";
                            }


                        }
                        else
                        {
                            label3.Text = "Rs.20,000";
                        }


                    }
                    else
                    {
                        label3.Text = "Rs.5,000";
                    }
                }
                else
                {
                    label3.Text = "Rs.5,000";
                }
            }
            if (label4.Text == "1")
            {
                if (label64.Text == "1")
                {
                    if (label65.Text == "1")
                    {
                        if (label66.Text == "1")
                        {
                            if (label67.Text == "1")
                            {
                                if (label68.Text == "1")
                                {
                                    if (label69.Text == "1")
                                    {
                                        if (label70.Text == "1")
                                        {
                                            label3.Text = "Rs.20,000";
                                        }
                                        else
                                        {
                                            label3.Text = "Rs.7,65,432";
                                        }

                                    }
                                    else
                                    {
                                        label3.Text = "Rs.7,65,432";
                                    }
                                }
                                else
                                {
                                    label3.Text = "Rs.2,20,000";
                                }

                            }
                            else
                            {
                                label3.Text = "Rs.5,20,000";
                            }


                        }
                        else
                        {
                            label3.Text = "Rs.20,000";
                        }


                    }
                    else
                    {
                        label3.Text = "Rs.5,000";
                    }
                }
                else
                {
                    label3.Text = "Rs.5,000";
                }
            }


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
